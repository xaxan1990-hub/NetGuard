using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;

namespace NetGuard;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            ApplicationConfiguration.Initialize();
            var state = new StateStore();
            Application.ThreadException += (_, e) => state.ReportError("Ошибка интерфейса", e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (_, e) => state.ReportError("Необработанная ошибка", e.ExceptionObject as Exception);
            var firewall = new FirewallManager(state);
            if (state.HasPendingTransition)
            {
                state.ReportError("Автоматическое восстановление после незавершённого изменения политики", null);
                firewall.Restore();
            }
            if (args.Contains("--restore", StringComparer.OrdinalIgnoreCase))
            {
                firewall.Restore();
                MessageBox.Show("Исходная конфигурация сети восстановлена.", "NetGuard");
                return;
            }
            Application.Run(new MainForm(state, firewall, args.Contains("--activate", StringComparer.OrdinalIgnoreCase)));
        }
        catch (Exception ex)
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NetGuard");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "startup-error.log"), $"{DateTimeOffset.Now:O}\r\n{ex}\r\n\r\n");
            MessageBox.Show("NetGuard не смог запуститься:\r\n\r\n" + ex.Message +
                "\r\n\r\nЖурнал: C:\\ProgramData\\NetGuard\\startup-error.log", "NetGuard — ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}

internal sealed class MainForm : Form
{
    private readonly StateStore state;
    private readonly FirewallManager firewall;
    private readonly DataGridView eventsGrid = new();
    private readonly DataGridView rulesGrid = new();
    private readonly Label status = new();
    private readonly BindingSource eventSource = new();
    private readonly BindingSource ruleSource = new();
    private readonly List<NetworkEvent> events = new();
    private readonly object eventLock = new();
    private EventLogWatcher? watcher;

    public MainForm(StateStore state, FirewallManager firewall, bool activateAfterOpen)
    {
        this.state = state;
        this.firewall = firewall;
        Text = "NetGuard — полный контроль сети";
        Width = 1250; Height = 760; StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9F);
        BuildUi();
        LoadHistory();
        RefreshRules();
        RefreshStatus();
        if (activateAfterOpen)
        {
            Shown += (_, _) => BeginInvoke(() =>
            {
                try { firewall.EnableStrictMode(); StartWfpAuditWatcher(); }
                catch (Exception ex)
                {
                    state.ReportError("Не удалось включить строгий режим", ex);
                    try { firewall.Restore(); } catch (Exception restoreError) { state.ReportError("Ошибка автоматического восстановления", restoreError); }
                    MessageBox.Show("Строгий режим не включён. Исходные сетевые настройки восстановлены.\r\n\r\n" + ex.Message,
                        "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                RefreshStatus(); RefreshRules();
            });
        }
        else StartWfpAuditWatcher();
    }

    private void BuildUi()
    {
        status.Dock = DockStyle.Top; status.Height = 38; status.Padding = new Padding(12, 10, 0, 0);
        status.Font = new Font("Segoe UI Semibold", 11F); Controls.Add(status);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(8, 5, 0, 0) };
        buttons.Controls.Add(Button("ЗАПРЕТИТЬ ВСЁ", (_, _) => EnableStrictSafely()));
        buttons.Controls.Add(Button("ВЕРНУТЬ ВСЁ КАК БЫЛО", (_, _) => SafeUi(RestoreWithConfirmation)));
        buttons.Controls.Add(Button("Разрешить EXE", (_, _) => SafeUi(AllowExe)));
        buttons.Controls.Add(Button("Разрешить службу", (_, _) => SafeUi(AllowService)));
        buttons.Controls.Add(Button("Запретить выбранный", (_, _) => SafeUi(RevokeSelected)));
        buttons.Controls.Add(Button("Очистить журнал", (_, _) => { state.ClearHistory(); lock(eventLock) events.Clear(); RefreshEvents(); }));
        Controls.Add(buttons);

        var tabs = new TabControl { Dock = DockStyle.Fill };
        eventsGrid.Dock = DockStyle.Fill; eventsGrid.ReadOnly = true; eventsGrid.AutoGenerateColumns = true;
        eventsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; eventsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        eventsGrid.DataSource = eventSource;
        rulesGrid.Dock = DockStyle.Fill; rulesGrid.ReadOnly = true; rulesGrid.AutoGenerateColumns = true;
        rulesGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; rulesGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        rulesGrid.DataSource = ruleSource;
        var now = new TabPage("Сейчас и история"); now.Controls.Add(eventsGrid);
        var rules = new TabPage("Разрешённые программы"); rules.Controls.Add(rulesGrid);
        tabs.TabPages.Add(now); tabs.TabPages.Add(rules); Controls.Add(tabs);
    }

    private static Button Button(string text, EventHandler handler)
    {
        var b = new Button { Text = text, AutoSize = true, Height = 34, Padding = new Padding(10, 0, 10, 0) };
        b.Click += handler; return b;
    }

    private void SafeUi(Action action)
    {
        try { action(); }
        catch (Exception ex)
        {
            state.ReportError("Ошибка операции", ex);
            MessageBox.Show(ex.Message + "\r\n\r\nПодробности: C:\\ProgramData\\NetGuard\\startup-error.log",
                "NetGuard — ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void StartWfpAuditWatcher()
    {
        try
        {
            firewall.EnsureAuditBackup();
            firewall.EnableWfpAuditing();
            var query = new EventLogQuery("Security", PathType.LogName,
                "*[System[(EventID=5152 or EventID=5156 or EventID=5157)]]");
            watcher = new EventLogWatcher(query);
            watcher.EventRecordWritten += (_, e) =>
            {
                if (e.EventRecord is null) return;
                try { AddEvent(NetworkEvent.FromRecord(e.EventRecord)); } catch { }
                finally { e.EventRecord.Dispose(); }
            };
            watcher.Enabled = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось включить журнал WFP: " + ex.Message, "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void AddEvent(NetworkEvent item)
    {
        state.AppendHistory(item);
        lock (eventLock)
        {
            events.Insert(0, item);
            if (events.Count > 5000) events.RemoveRange(5000, events.Count - 5000);
        }
        if (IsHandleCreated) BeginInvoke(RefreshEvents);
    }

    private void LoadHistory()
    {
        lock (eventLock)
        {
            events.Clear();
            events.AddRange(state.ReadHistory(5000));
        }
        RefreshEvents();
    }

    private void EnableStrictSafely()
    {
        try { firewall.EnableStrictMode(); }
        catch (Exception ex)
        {
            state.ReportError("Не удалось включить строгий режим", ex);
            try { firewall.Restore(); } catch (Exception restoreError) { state.ReportError("Ошибка восстановления", restoreError); }
            MessageBox.Show("Строгий режим не включён. Выполнено восстановление.\r\n\r\n" + ex.Message,
                "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        RefreshStatus(); RefreshRules();
    }

    private void RefreshEvents()
    {
        List<NetworkEvent> copy; lock(eventLock) copy = events.ToList();
        eventSource.DataSource = copy;
    }

    private void AllowExe()
    {
        using var dlg = new OpenFileDialog { Filter = "Программы (*.exe)|*.exe", CheckFileExists = true };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        firewall.AllowProgram(dlg.FileName); RefreshRules(); RefreshStatus();
    }

    private void RevokeSelected()
    {
        if (rulesGrid.CurrentRow?.DataBoundItem is not AllowedRule item) return;
        firewall.RevokeRule(item.Name); RefreshRules(); RefreshStatus();
    }

    private void AllowService()
    {
        using var picker = new ServicePickerForm(firewall.GetRunningServices());
        if (picker.ShowDialog(this) != DialogResult.OK || picker.SelectedService is null) return;
        firewall.AllowService(picker.SelectedService); RefreshRules(); RefreshStatus();
    }

    private void RestoreWithConfirmation()
    {
        if (MessageBox.Show("Полностью вернуть настройки брандмауэра и аудита, сохранённые до NetGuard?", "NetGuard",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        firewall.Restore(); RefreshRules(); RefreshStatus();
    }

    private void RefreshRules() => ruleSource.DataSource = firewall.GetAllowedRules();
    private void RefreshStatus()
    {
        bool strict = state.IsStrict;
        status.Text = strict ? "🔴 СТРОГИЙ РЕЖИМ: всё запрещено, кроме списка разрешений" : "🟢 Исходная политика Windows восстановлена";
        status.ForeColor = strict ? Color.DarkRed : Color.DarkGreen;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) watcher?.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class FirewallManager
{
    private readonly StateStore state;
    private const string Group = "NetGuard Managed Rules";
    public FirewallManager(StateStore state) => this.state = state;

    public void EnableStrictMode()
    {
        if (state.IsStrict) return;
        Directory.CreateDirectory(state.DataDirectory);
        state.BeginTransition();
        if (!File.Exists(state.FirewallBackup)) Run("netsh", $"advfirewall export \"{state.FirewallBackup}\"");
        EnsureAuditBackup();
        RunPowerShell("Get-NetFirewallRule -Enabled True -Action Allow | Disable-NetFirewallRule");
        RunPowerShell("Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block -DefaultOutboundAction Block");
        state.SetStrict(true);
        state.EndTransition();
        EnableWfpAuditing();
    }

    public void Restore()
    {
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Remove-NetFirewallRule");
        if (File.Exists(state.FirewallBackup)) Run("netsh", $"advfirewall import \"{state.FirewallBackup}\"");
        if (File.Exists(state.AuditBackup)) Run("auditpol", $"/restore /file:\"{state.AuditBackup}\"");
        state.SetStrict(false);
        state.EndTransition();
        if (File.Exists(state.FirewallBackup)) File.Delete(state.FirewallBackup);
        if (File.Exists(state.AuditBackup)) File.Delete(state.AuditBackup);
    }

    public void EnsureAuditBackup()
    {
        Directory.CreateDirectory(state.DataDirectory);
        if (!File.Exists(state.AuditBackup)) Run("auditpol", $"/backup /file:\"{state.AuditBackup}\"");
    }

    public void EnableWfpAuditing()
    {
        Run("auditpol", "/set /subcategory:{0CCE9225-69AE-11D9-BED3-505054503030} /success:enable /failure:enable", false, true);
        Run("auditpol", "/set /subcategory:{0CCE9226-69AE-11D9-BED3-505054503030} /success:enable /failure:enable", false, true);
    }

    public void AllowProgram(string path)
    {
        string escaped = path.Replace("'", "''");
        string id = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(path)))[..24];
        RunPowerShell($"New-NetFirewallRule -Name 'NetGuard-{id}-Out' -DisplayName 'NetGuard allow outbound: {escaped}' -Group '{Group}' -Direction Outbound -Action Allow -Program '{escaped}' -Profile Any -Protocol Any; New-NetFirewallRule -Name 'NetGuard-{id}-In' -DisplayName 'NetGuard allow inbound: {escaped}' -Group '{Group}' -Direction Inbound -Action Allow -Program '{escaped}' -Profile Any -Protocol Any");
    }

    public void RevokeProgram(string path)
    {
        string escaped = path.Replace("'", "''");
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Where-Object {{ ($_ | Get-NetFirewallApplicationFilter).Program -ieq '{escaped}' }} | Remove-NetFirewallRule");
    }

    public void AllowService(ServiceInfo service)
    {
        string escaped = service.Name.Replace("'", "''");
        string id = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes("service:" + service.Name)))[..24];
        RunPowerShell($"New-NetFirewallRule -Name 'NetGuard-Svc-{id}-Out' -DisplayName 'NetGuard service outbound: {escaped}' -Group '{Group}' -Direction Outbound -Action Allow -Service '{escaped}' -Profile Any -Protocol Any; New-NetFirewallRule -Name 'NetGuard-Svc-{id}-In' -DisplayName 'NetGuard service inbound: {escaped}' -Group '{Group}' -Direction Inbound -Action Allow -Service '{escaped}' -Profile Any -Protocol Any");
    }

    public void RevokeRule(string name)
    {
        string escaped = name.Replace("'", "''");
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Where-Object {{ $_.Name -like '{escaped}*' }} | Remove-NetFirewallRule");
    }

    public List<ServiceInfo> GetRunningServices()
    {
        string json = RunPowerShell("Get-CimInstance Win32_Service | Where-Object State -eq 'Running' | Select-Object Name,DisplayName,ProcessId | Sort-Object DisplayName | ConvertTo-Json -Compress", true);
        if (string.IsNullOrWhiteSpace(json)) return new();
        try
        {
            if (json.TrimStart().StartsWith("[")) return JsonSerializer.Deserialize<List<ServiceInfo>>(json, JsonOptions.Options) ?? new();
            var one = JsonSerializer.Deserialize<ServiceInfo>(json, JsonOptions.Options); return one is null ? new() : new() { one };
        }
        catch { return new(); }
    }

    public List<AllowedRule> GetAllowedRules()
    {
        string script = $"Get-NetFirewallRule -Group '{Group}' -Enabled True -ErrorAction SilentlyContinue | ForEach-Object {{ $p=($_ | Get-NetFirewallApplicationFilter).Program; $s=($_ | Get-NetFirewallServiceFilter).Service; $base=$_.Name -replace '-(Out|In)$',''; if($s -and $s -ne 'Any') {{ [pscustomobject]@{{Name=$base;Type='Служба';Target=$s}} }} elseif($p -and $p -ne 'Any') {{ [pscustomobject]@{{Name=$base;Type='Программа';Target=$p}} }} }} | Sort-Object Name -Unique | ConvertTo-Json -Compress";
        string json = RunPowerShell(script, true);
        if (string.IsNullOrWhiteSpace(json)) return new();
        try
        {
            if (json.TrimStart().StartsWith("[")) return JsonSerializer.Deserialize<List<AllowedRule>>(json, JsonOptions.Options) ?? new();
            var one = JsonSerializer.Deserialize<AllowedRule>(json, JsonOptions.Options); return one is null ? new() : new() { one };
        }
        catch { return new(); }
    }

    private static string RunPowerShell(string script, bool capture = false) =>
        Run("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"" + script.Replace("\"", "\\\"") + "\"", capture);

    private static string Run(string file, string args, bool capture = false, bool ignoreExitCode = false)
    {
        using var p = Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = capture, RedirectStandardError = true })
            ?? throw new InvalidOperationException("Не удалось запустить " + file);
        string output = capture ? p.StandardOutput.ReadToEnd() : "";
        string error = p.StandardError.ReadToEnd(); p.WaitForExit();
        if (p.ExitCode != 0 && !ignoreExitCode) throw new InvalidOperationException($"{file} завершился с кодом {p.ExitCode}: {error}");
        return output;
    }
}

internal sealed class StateStore
{
    public string DataDirectory { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NetGuard");
    public string FirewallBackup => Path.Combine(DataDirectory, "firewall-before-netguard.wfw");
    public string AuditBackup => Path.Combine(DataDirectory, "audit-before-netguard.csv");
    private string Marker => Path.Combine(DataDirectory, "strict-mode.enabled");
    private string Transition => Path.Combine(DataDirectory, "transition.pending");
    private string History => Path.Combine(DataDirectory, "history.jsonl");
    public bool IsStrict => File.Exists(Marker);
    public bool HasPendingTransition => File.Exists(Transition);
    public void BeginTransition() { Directory.CreateDirectory(DataDirectory); File.WriteAllText(Transition, DateTimeOffset.UtcNow.ToString("O")); }
    public void EndTransition() { if (File.Exists(Transition)) File.Delete(Transition); }
    public void SetStrict(bool value) { Directory.CreateDirectory(DataDirectory); if (value) File.WriteAllText(Marker, DateTimeOffset.UtcNow.ToString("O")); else if (File.Exists(Marker)) File.Delete(Marker); }
    public void AppendHistory(NetworkEvent item) { Directory.CreateDirectory(DataDirectory); File.AppendAllText(History, JsonSerializer.Serialize(item) + Environment.NewLine, Encoding.UTF8); }
    public List<NetworkEvent> ReadHistory(int limit)
    {
        if (!File.Exists(History)) return new();
        var result = new List<NetworkEvent>();
        foreach (string line in File.ReadLines(History).Reverse().Take(limit))
        {
            try { var item = JsonSerializer.Deserialize<NetworkEvent>(line, JsonOptions.Options); if (item is not null) result.Add(item); } catch { }
        }
        return result;
    }
    public void ClearHistory() { if (File.Exists(History)) File.Delete(History); }
    public void ReportError(string title, Exception? error)
    {
        Directory.CreateDirectory(DataDirectory);
        File.AppendAllText(Path.Combine(DataDirectory, "startup-error.log"), $"{DateTimeOffset.Now:O} {title}\r\n{error}\r\n\r\n", Encoding.UTF8);
    }
}

internal sealed record AllowedRule(string Name, string Type, string Target);
internal sealed record ServiceInfo(string Name, string DisplayName, uint ProcessId);

internal sealed class ServicePickerForm : Form
{
    private readonly DataGridView grid = new();
    public ServiceInfo? SelectedService { get; private set; }
    public ServicePickerForm(List<ServiceInfo> services)
    {
        Text = "Выберите службу Windows"; Width = 760; Height = 520; StartPosition = FormStartPosition.CenterParent;
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.DataSource = services;
        var ok = new Button { Text = "Разрешить выбранную службу", Dock = DockStyle.Bottom, Height = 42 };
        ok.Click += (_, _) => { SelectedService = grid.CurrentRow?.DataBoundItem as ServiceInfo; if (SelectedService is not null) DialogResult = DialogResult.OK; };
        Controls.Add(grid); Controls.Add(ok);
    }
}

internal sealed record NetworkEvent(DateTime Time, string Result, string Application, string ProcessId, string Direction,
    string Protocol, string Source, string Destination)
{
    public static NetworkEvent FromRecord(EventRecord record)
    {
        var doc = XDocument.Parse(record.ToXml());
        XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
        var values = doc.Descendants(ns + "Data").Where(x => x.Attribute("Name") != null)
            .ToDictionary(x => x.Attribute("Name")!.Value, x => x.Value, StringComparer.OrdinalIgnoreCase);
        string Get(string key) => values.TryGetValue(key, out var value) ? value : "";
        string result = record.Id switch { 5156 => "РАЗРЕШЕНО", 5152 or 5157 => "ЗАБЛОКИРОВАНО", _ => record.Id.ToString() };
        string protocol = Get("Protocol") switch { "6" => "TCP", "17" => "UDP", var p => p };
        return new(record.TimeCreated ?? DateTime.Now, result, Get("Application"), Get("ProcessID"), Get("Direction"), protocol,
            $"{Get("SourceAddress")}:{Get("SourcePort")}", $"{Get("DestAddress")}:{Get("DestPort")}");
    }
}

internal static class JsonOptions
{
    public static readonly JsonSerializerOptions Options = new() { PropertyNameCaseInsensitive = true };
}

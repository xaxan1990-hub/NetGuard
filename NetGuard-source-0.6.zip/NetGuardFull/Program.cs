using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using System.Runtime.InteropServices;

namespace NetGuard;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            ApplicationConfiguration.Initialize();
            var state = new StateStore();
            Application.ThreadException += (_, e) => state.ReportError("Ошибка интерфейса", e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (_, e) => state.ReportError("Необработанная ошибка", e.ExceptionObject as Exception);
            var firewall = new FirewallManager(state);
            if (state.HasPendingTransition)
            {
                state.ReportError("Автоматическое восстановление после незавершённого изменения политики", null);
                firewall.Restore();
            }
            if (args.Contains("--restore", StringComparer.OrdinalIgnoreCase))
            {
                firewall.Restore();
                MessageBox.Show("Исходная конфигурация сети восстановлена.", "NetGuard");
                return;
            }
            Application.Run(new MainForm(state, firewall, args.Contains("--activate", StringComparer.OrdinalIgnoreCase)));
        }
        catch (Exception ex)
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NetGuard");
            Directory.CreateDirectory(dir);
            File.AppendAllText(Path.Combine(dir, "startup-error.log"), $"{DateTimeOffset.Now:O}\r\n{ex}\r\n\r\n");
            MessageBox.Show("NetGuard не смог запуститься:\r\n\r\n" + ex.Message +
                "\r\n\r\nЖурнал: C:\\ProgramData\\NetGuard\\startup-error.log", "NetGuard — ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}

internal sealed class MainForm : Form
{
    private readonly StateStore state;
    private readonly FirewallManager firewall;
    private readonly DataGridView eventsGrid = new();
    private readonly DataGridView rulesGrid = new();
    private readonly Label status = new();
    private readonly Label statusDetails = new();
    private readonly Label eventCount = new();
    private readonly TextBox searchBox = new();
    private readonly CheckBox promptToggle = new();
    private readonly HashSet<string> promptedApplications = new(StringComparer.OrdinalIgnoreCase);
    private bool promptVisible;
    private readonly BindingSource eventSource = new();
    private readonly BindingSource ruleSource = new();
    private readonly List<NetworkEvent> events = new();
    private readonly object eventLock = new();
    private EventLogWatcher? watcher;

    public MainForm(StateStore state, FirewallManager firewall, bool activateAfterOpen)
    {
        this.state = state;
        this.firewall = firewall;
        Text = "NetGuard — полный контроль сети";
        Width = 1250; Height = 760; StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9F);
        BuildUi();
        LoadHistory();
        RefreshRules();
        RefreshStatus();
        if (activateAfterOpen)
        {
            Shown += (_, _) => BeginInvoke(() =>
            {
                try { firewall.EnableStrictMode(); StartWfpAuditWatcher(); }
                catch (Exception ex)
                {
                    state.ReportError("Не удалось включить строгий режим", ex);
                    try { firewall.Restore(); } catch (Exception restoreError) { state.ReportError("Ошибка автоматического восстановления", restoreError); }
                    MessageBox.Show("Строгий режим не включён. Исходные сетевые настройки восстановлены.\r\n\r\n" + ex.Message,
                        "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                RefreshStatus(); RefreshRules();
            });
        }
        else StartWfpAuditWatcher();
    }

    private void BuildUi()
    {
        BackColor = Color.FromArgb(244, 246, 249);
        MinimumSize = new Size(950, 600);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(14) };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var statusCard = new Panel { Dock = DockStyle.Fill, Padding = new Padding(18, 12, 18, 8), Margin = new Padding(0, 0, 0, 10) };
        status.Font = new Font("Segoe UI Semibold", 17F); status.AutoSize = true; status.Location = new Point(16, 10);
        statusDetails.Font = new Font("Segoe UI", 10F); statusDetails.AutoSize = true; statusDetails.Location = new Point(19, 51);
        statusCard.Controls.Add(status); statusCard.Controls.Add(statusDetails);
        root.Controls.Add(statusCard, 0, 0);

        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0, 5, 0, 6), WrapContents = false, AutoScroll = true };
        buttons.Controls.Add(ActionButton("Заблокировать интернет", Color.FromArgb(192, 45, 45), (_, _) => EnableStrictSafely(), "Запретить весь входящий и исходящий трафик, кроме разрешённого списка"));
        buttons.Controls.Add(ActionButton("Вернуть обычный доступ", Color.FromArgb(34, 139, 84), (_, _) => SafeUi(RestoreWithConfirmation), "Восстановить настройки Windows, сохранённые до включения защиты"));
        buttons.Controls.Add(ActionButton("+ Разрешить программу", Color.FromArgb(45, 100, 185), (_, _) => SafeUi(AllowExe), "Выбрать EXE-файл, которому нужен доступ к сети"));
        buttons.Controls.Add(ActionButton("+ Разрешить службу", Color.FromArgb(75, 85, 105), (_, _) => SafeUi(AllowService), "Разрешить выбранную работающую службу Windows"));
        promptToggle.Text = "Спрашивать о новых приложениях";
        promptToggle.Checked = state.PromptMode;
        promptToggle.AutoSize = true; promptToggle.Padding = new Padding(10, 9, 6, 0);
        promptToggle.Font = new Font("Segoe UI Semibold", 9F);
        promptToggle.CheckedChanged += (_, _) => state.SetPromptMode(promptToggle.Checked);
        new ToolTip().SetToolTip(promptToggle, "При заблокированной попытке нового приложения предложить постоянное разрешение");
        buttons.Controls.Add(promptToggle);
        root.Controls.Add(buttons, 0, 1);

        ConfigureGrid(eventsGrid);
        eventsGrid.Columns.AddRange(
            GridColumn("Time", "Время", 150), GridColumn("Result", "Решение", 135),
            GridColumn("Application", "Программа / путь", 310), GridColumn("ProcessId", "PID", 70),
            GridColumn("Direction", "Направление", 105), GridColumn("Protocol", "Протокол", 85),
            GridColumn("Source", "Источник", 175), GridColumn("Destination", "Назначение", 175));
        eventsGrid.DataSource = eventSource;
        eventsGrid.CellFormatting += (_, e) =>
        {
            if (e.RowIndex < 0) return;
            if (eventsGrid.Rows[e.RowIndex].DataBoundItem is not NetworkEvent item) return;
            eventsGrid.Rows[e.RowIndex].DefaultCellStyle.BackColor = item.Result == "ЗАБЛОКИРОВАНО" ? Color.FromArgb(255, 235, 235) : Color.FromArgb(235, 250, 241);
            if (eventsGrid.Columns[e.ColumnIndex].DataPropertyName == "Time" && e.Value is DateTime time) { e.Value = time.ToString("dd.MM.yyyy HH:mm:ss"); e.FormattingApplied = true; }
        };

        ConfigureGrid(rulesGrid);
        rulesGrid.Columns.AddRange(GridColumn("Type", "Тип", 110), GridColumn("Target", "Разрешённая программа или служба", 650));
        rulesGrid.DataSource = ruleSource;

        var eventPage = new TabPage("Сетевая активность") { BackColor = Color.White, Padding = new Padding(8) };
        var eventTools = new Panel { Dock = DockStyle.Top, Height = 43 };
        var searchLabel = new Label { Text = "Поиск:", AutoSize = true, Location = new Point(4, 12) };
        searchBox.SetBounds(58, 7, 330, 28); searchBox.PlaceholderText = "программа, IP, порт или результат";
        searchBox.TextChanged += (_, _) => RefreshEvents();
        eventCount.AutoSize = true; eventCount.Location = new Point(405, 12); eventCount.ForeColor = Color.DimGray;
        var clear = ActionButton("Очистить историю", Color.FromArgb(100, 105, 115), (_, _) => { state.ClearHistory(); lock(eventLock) events.Clear(); RefreshEvents(); }, "Удалить сохранённую историю событий");
        clear.Anchor = AnchorStyles.Top | AnchorStyles.Right; clear.SetBounds(1010, 4, 165, 34);
        eventTools.Resize += (_, _) => clear.Left = Math.Max(420, eventTools.ClientSize.Width - clear.Width - 4);
        eventTools.Controls.AddRange(new Control[] { searchLabel, searchBox, eventCount, clear });
        eventPage.Controls.Add(eventsGrid); eventPage.Controls.Add(eventTools);

        var rulesPage = new TabPage("Разрешённые приложения") { BackColor = Color.White, Padding = new Padding(8) };
        var ruleTools = new Panel { Dock = DockStyle.Top, Height = 43 };
        var hint = new Label { Text = "Только эти источники имеют сеть в режиме блокировки.", AutoSize = true, Location = new Point(4, 12), ForeColor = Color.DimGray };
        var revoke = ActionButton("Убрать разрешение", Color.FromArgb(192, 45, 45), (_, _) => SafeUi(RevokeSelected), "Запретить сеть выбранной программе или службе");
        revoke.Anchor = AnchorStyles.Top | AnchorStyles.Right; revoke.SetBounds(1010, 4, 165, 34);
        ruleTools.Resize += (_, _) => revoke.Left = Math.Max(420, ruleTools.ClientSize.Width - revoke.Width - 4);
        ruleTools.Controls.AddRange(new Control[] { hint, revoke });
        rulesPage.Controls.Add(rulesGrid); rulesPage.Controls.Add(ruleTools);

        var tabs = new TabControl { Dock = DockStyle.Fill, Font = new Font("Segoe UI Semibold", 10F) };
        tabs.TabPages.Add(eventPage); tabs.TabPages.Add(rulesPage);
        root.Controls.Add(tabs, 0, 2);
        Controls.Add(root);
    }

    private static Button ActionButton(string text, Color color, EventHandler handler, string tip)
    {
        var b = new Button { Text = text, AutoSize = true, Height = 38, Padding = new Padding(12, 0, 12, 0), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White, Cursor = Cursors.Hand };
        b.FlatAppearance.BorderSize = 0; b.Click += handler; new ToolTip().SetToolTip(b, tip); return b;
    }

    private static void ConfigureGrid(DataGridView grid)
    {
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AutoGenerateColumns = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = false;
        grid.AllowUserToResizeColumns = true; grid.AllowUserToOrderColumns = true;
        grid.AllowUserToAddRows = false; grid.AllowUserToDeleteRows = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        grid.BackgroundColor = Color.White; grid.BorderStyle = BorderStyle.None;
        grid.RowHeadersVisible = false; grid.RowTemplate.Height = 30;
        grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersHeight = 36;
        grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(229, 234, 241);
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9F);
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 251);
    }

    private static DataGridViewTextBoxColumn GridColumn(string property, string title, int width) =>
        new() { DataPropertyName = property, HeaderText = title, Name = property, Width = width, MinimumWidth = 55, SortMode = DataGridViewColumnSortMode.Automatic };

    private void SafeUi(Action action)
    {
        try { action(); }
        catch (Exception ex)
        {
            state.ReportError("Ошибка операции", ex);
            MessageBox.Show(ex.Message + "\r\n\r\nПодробности: C:\\ProgramData\\NetGuard\\startup-error.log",
                "NetGuard — ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void StartWfpAuditWatcher()
    {
        try
        {
            firewall.EnsureAuditBackup();
            firewall.EnableWfpAuditing();
            var query = new EventLogQuery("Security", PathType.LogName,
                "*[System[(EventID=5152 or EventID=5156 or EventID=5157)]]");
            watcher = new EventLogWatcher(query);
            watcher.EventRecordWritten += (_, e) =>
            {
                if (e.EventRecord is null) return;
                try { AddEvent(NetworkEvent.FromRecord(e.EventRecord)); } catch { }
                finally { e.EventRecord.Dispose(); }
            };
            watcher.Enabled = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось включить журнал WFP: " + ex.Message, "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void AddEvent(NetworkEvent item)
    {
        state.AppendHistory(item);
        lock (eventLock)
        {
            events.Insert(0, item);
            if (events.Count > 5000) events.RemoveRange(5000, events.Count - 5000);
        }
        if (IsHandleCreated) BeginInvoke(() => { RefreshEvents(); MaybePromptForApplication(item); });
    }

    private void MaybePromptForApplication(NetworkEvent item)
    {
        if (!state.IsStrict || !promptToggle.Checked || item.Result != "ЗАБЛОКИРОВАНО" || promptVisible) return;
        string? path = ResolveExecutable(item);
        if (path is null || !promptedApplications.Add(path)) return;

        promptVisible = true;
        try
        {
            string name = Path.GetFileName(path);
            var answer = MessageBox.Show(
                $"Приложение пытается выйти в интернет:\r\n\r\n{name}\r\n{path}\r\n\r\nАдрес: {item.Destination}\r\nПротокол: {item.Protocol}\r\n\r\nРазрешить ему доступ постоянно?",
                "NetGuard — новое приложение", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (answer == DialogResult.Yes)
            {
                SafeUi(() => { firewall.AllowProgram(path); RefreshRules(); });
            }
        }
        finally { promptVisible = false; }
    }

    private static string? ResolveExecutable(NetworkEvent item)
    {
        if (int.TryParse(item.ProcessId, out int pid) && pid > 0)
        {
            try
            {
                using var process = Process.GetProcessById(pid);
                string? livePath = process.MainModule?.FileName;
                if (!string.IsNullOrWhiteSpace(livePath) && File.Exists(livePath)) return livePath;
            }
            catch { }
        }

        string path = item.Application.Trim();
        if (File.Exists(path) && path.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return Path.GetFullPath(path);
        if (!path.StartsWith(@"\device\", StringComparison.OrdinalIgnoreCase)) return null;
        foreach (string drive in Environment.GetLogicalDrives())
        {
            var target = new StringBuilder(512);
            if (QueryDosDevice(drive[..2], target, target.Capacity) == 0) continue;
            string device = target.ToString();
            if (!path.StartsWith(device, StringComparison.OrdinalIgnoreCase)) continue;
            string candidate = drive[..2] + path[device.Length..];
            if (File.Exists(candidate) && candidate.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) return candidate;
        }
        return null;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern uint QueryDosDevice(string lpDeviceName, StringBuilder lpTargetPath, int ucchMax);

    private void LoadHistory()
    {
        lock (eventLock)
        {
            events.Clear();
            events.AddRange(state.ReadHistory(5000));
        }
        RefreshEvents();
    }

    private void EnableStrictSafely()
    {
        try { firewall.EnableStrictMode(); }
        catch (Exception ex)
        {
            state.ReportError("Не удалось включить строгий режим", ex);
            try { firewall.Restore(); } catch (Exception restoreError) { state.ReportError("Ошибка восстановления", restoreError); }
            MessageBox.Show("Строгий режим не включён. Выполнено восстановление.\r\n\r\n" + ex.Message,
                "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        RefreshStatus(); RefreshRules();
    }

    private void RefreshEvents()
    {
        List<NetworkEvent> copy; lock(eventLock) copy = events.ToList();
        string q = searchBox.Text.Trim();
        if (q.Length > 0) copy = copy.Where(x => new[] { x.Result, x.Application, x.ProcessId, x.Direction, x.Protocol, x.Source, x.Destination }.Any(v => v.Contains(q, StringComparison.OrdinalIgnoreCase))).ToList();
        eventSource.DataSource = copy;
        eventCount.Text = $"Показано: {copy.Count}";
    }

    private void AllowExe()
    {
        using var dlg = new OpenFileDialog { Filter = "Программы (*.exe)|*.exe", CheckFileExists = true };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        firewall.AllowProgram(dlg.FileName); RefreshRules(); RefreshStatus();
    }

    private void RevokeSelected()
    {
        if (rulesGrid.CurrentRow?.DataBoundItem is not AllowedRule item) return;
        firewall.RevokeRule(item.Name); RefreshRules(); RefreshStatus();
    }

    private void AllowService()
    {
        using var picker = new ServicePickerForm(firewall.GetRunningServices());
        if (picker.ShowDialog(this) != DialogResult.OK || picker.SelectedService is null) return;
        firewall.AllowService(picker.SelectedService); RefreshRules(); RefreshStatus();
    }

    private void RestoreWithConfirmation()
    {
        if (MessageBox.Show("Полностью вернуть настройки брандмауэра и аудита, сохранённые до NetGuard?", "NetGuard",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        firewall.Restore(); RefreshRules(); RefreshStatus();
    }

    private void RefreshRules()
    {
        try { ruleSource.DataSource = firewall.GetAllowedRules(); }
        catch (Exception ex)
        {
            state.ReportError("Не удалось обновить список разрешений", ex);
            ruleSource.DataSource = new List<AllowedRule>();
        }
    }
    private void RefreshStatus()
    {
        bool strict = state.IsStrict;
        status.Text = strict ? "● ИНТЕРНЕТ ЗАБЛОКИРОВАН" : "● ОБЫЧНЫЙ ДОСТУП ВКЛЮЧЁН";
        statusDetails.Text = strict ? "Доступ к сети имеют только программы и службы из вкладки «Разрешённые приложения»." : "Действуют исходные правила брандмауэра Windows. NetGuard только показывает активность.";
        status.ForeColor = strict ? Color.FromArgb(150, 25, 25) : Color.FromArgb(20, 105, 62);
        statusDetails.ForeColor = strict ? Color.FromArgb(115, 40, 40) : Color.FromArgb(38, 90, 66);
        if (status.Parent is not null) status.Parent.BackColor = strict ? Color.FromArgb(255, 225, 225) : Color.FromArgb(222, 247, 232);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) watcher?.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class FirewallManager
{
    private readonly StateStore state;
    private const string Group = "NetGuard Managed Rules";
    public FirewallManager(StateStore state) => this.state = state;

    public void EnableStrictMode()
    {
        if (state.IsStrict) return;
        Directory.CreateDirectory(state.DataDirectory);
        state.BeginTransition();
        if (!File.Exists(state.FirewallBackup)) Run("netsh", $"advfirewall export \"{state.FirewallBackup}\"");
        EnsureAuditBackup();
        RunPowerShell("Get-NetFirewallRule -Enabled True -Action Allow | Disable-NetFirewallRule");
        RunPowerShell("Set-NetFirewallProfile -Profile Domain,Private,Public -DefaultInboundAction Block -DefaultOutboundAction Block");
        state.SetStrict(true);
        state.EndTransition();
        EnableWfpAuditing();
    }

    public void Restore()
    {
        // An empty group is normal. PowerShell may still return exit code 1, so only this cleanup is best-effort.
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue", false, true);
        if (File.Exists(state.FirewallBackup)) Run("netsh", $"advfirewall import \"{state.FirewallBackup}\"");
        if (File.Exists(state.AuditBackup)) Run("auditpol", $"/restore /file:\"{state.AuditBackup}\"");
        state.SetStrict(false);
        state.EndTransition();
        if (File.Exists(state.FirewallBackup)) File.Delete(state.FirewallBackup);
        if (File.Exists(state.AuditBackup)) File.Delete(state.AuditBackup);
    }

    public void EnsureAuditBackup()
    {
        Directory.CreateDirectory(state.DataDirectory);
        if (!File.Exists(state.AuditBackup)) Run("auditpol", $"/backup /file:\"{state.AuditBackup}\"");
    }

    public void EnableWfpAuditing()
    {
        Run("auditpol", "/set /subcategory:{0CCE9225-69AE-11D9-BED3-505054503030} /success:enable /failure:enable", false, true);
        Run("auditpol", "/set /subcategory:{0CCE9226-69AE-11D9-BED3-505054503030} /success:enable /failure:enable", false, true);
    }

    public void AllowProgram(string path)
    {
        string escaped = path.Replace("'", "''");
        string id = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(path)))[..24];
        RunPowerShell($"New-NetFirewallRule -Name 'NetGuard-{id}-Out' -DisplayName 'NetGuard allow outbound: {escaped}' -Group '{Group}' -Direction Outbound -Action Allow -Program '{escaped}' -Profile Any -Protocol Any; New-NetFirewallRule -Name 'NetGuard-{id}-In' -DisplayName 'NetGuard allow inbound: {escaped}' -Group '{Group}' -Direction Inbound -Action Allow -Program '{escaped}' -Profile Any -Protocol Any");
    }

    public void RevokeProgram(string path)
    {
        string escaped = path.Replace("'", "''");
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Where-Object {{ ($_ | Get-NetFirewallApplicationFilter).Program -ieq '{escaped}' }} | Remove-NetFirewallRule");
    }

    public void AllowService(ServiceInfo service)
    {
        string escaped = service.Name.Replace("'", "''");
        string id = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes("service:" + service.Name)))[..24];
        RunPowerShell($"New-NetFirewallRule -Name 'NetGuard-Svc-{id}-Out' -DisplayName 'NetGuard service outbound: {escaped}' -Group '{Group}' -Direction Outbound -Action Allow -Service '{escaped}' -Profile Any -Protocol Any; New-NetFirewallRule -Name 'NetGuard-Svc-{id}-In' -DisplayName 'NetGuard service inbound: {escaped}' -Group '{Group}' -Direction Inbound -Action Allow -Service '{escaped}' -Profile Any -Protocol Any");
    }

    public void RevokeRule(string name)
    {
        string escaped = name.Replace("'", "''");
        RunPowerShell($"Get-NetFirewallRule -Group '{Group}' -ErrorAction SilentlyContinue | Where-Object {{ $_.Name -like '{escaped}*' }} | Remove-NetFirewallRule");
    }

    public List<ServiceInfo> GetRunningServices()
    {
        string json = RunPowerShell("Get-CimInstance Win32_Service | Where-Object State -eq 'Running' | Select-Object Name,DisplayName,ProcessId | Sort-Object DisplayName | ConvertTo-Json -Compress", true);
        if (string.IsNullOrWhiteSpace(json)) return new();
        try
        {
            if (json.TrimStart().StartsWith("[")) return JsonSerializer.Deserialize<List<ServiceInfo>>(json, JsonOptions.Options) ?? new();
            var one = JsonSerializer.Deserialize<ServiceInfo>(json, JsonOptions.Options); return one is null ? new() : new() { one };
        }
        catch { return new(); }
    }

    public List<AllowedRule> GetAllowedRules()
    {
        string script = $"Get-NetFirewallRule -Group '{Group}' -Enabled True -ErrorAction SilentlyContinue | ForEach-Object {{ $p=($_ | Get-NetFirewallApplicationFilter).Program; $s=($_ | Get-NetFirewallServiceFilter).Service; $base=$_.Name -replace '-(Out|In)$',''; if($s -and $s -ne 'Any') {{ [pscustomobject]@{{Name=$base;Type='Служба';Target=$s}} }} elseif($p -and $p -ne 'Any') {{ [pscustomobject]@{{Name=$base;Type='Программа';Target=$p}} }} }} | Sort-Object Name -Unique | ConvertTo-Json -Compress";
        string json = RunPowerShell(script, true, true);
        if (string.IsNullOrWhiteSpace(json)) return new();
        try
        {
            if (json.TrimStart().StartsWith("[")) return JsonSerializer.Deserialize<List<AllowedRule>>(json, JsonOptions.Options) ?? new();
            var one = JsonSerializer.Deserialize<AllowedRule>(json, JsonOptions.Options); return one is null ? new() : new() { one };
        }
        catch { return new(); }
    }

    private static string RunPowerShell(string script, bool capture = false, bool ignoreExitCode = false) =>
        Run("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -Command \"" + script.Replace("\"", "\\\"") + "\"", capture, ignoreExitCode);

    private static string Run(string file, string args, bool capture = false, bool ignoreExitCode = false)
    {
        using var p = Process.Start(new ProcessStartInfo(file, args) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = capture, RedirectStandardError = true })
            ?? throw new InvalidOperationException("Не удалось запустить " + file);
        string output = capture ? p.StandardOutput.ReadToEnd() : "";
        string error = p.StandardError.ReadToEnd(); p.WaitForExit();
        if (p.ExitCode != 0 && !ignoreExitCode) throw new InvalidOperationException($"{file} завершился с кодом {p.ExitCode}: {error}");
        return output;
    }
}

internal sealed class StateStore
{
    public string DataDirectory { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NetGuard");
    public string FirewallBackup => Path.Combine(DataDirectory, "firewall-before-netguard.wfw");
    public string AuditBackup => Path.Combine(DataDirectory, "audit-before-netguard.csv");
    private string Marker => Path.Combine(DataDirectory, "strict-mode.enabled");
    private string Transition => Path.Combine(DataDirectory, "transition.pending");
    private string History => Path.Combine(DataDirectory, "history.jsonl");
    private string PromptSetting => Path.Combine(DataDirectory, "prompt-new-apps.enabled");
    public bool IsStrict => File.Exists(Marker);
    public bool HasPendingTransition => File.Exists(Transition);
    public bool PromptMode => File.Exists(PromptSetting);
    public void BeginTransition() { Directory.CreateDirectory(DataDirectory); File.WriteAllText(Transition, DateTimeOffset.UtcNow.ToString("O")); }
    public void EndTransition() { if (File.Exists(Transition)) File.Delete(Transition); }
    public void SetStrict(bool value) { Directory.CreateDirectory(DataDirectory); if (value) File.WriteAllText(Marker, DateTimeOffset.UtcNow.ToString("O")); else if (File.Exists(Marker)) File.Delete(Marker); }
    public void SetPromptMode(bool value) { Directory.CreateDirectory(DataDirectory); if (value) File.WriteAllText(PromptSetting, "1"); else if (File.Exists(PromptSetting)) File.Delete(PromptSetting); }
    public void AppendHistory(NetworkEvent item) { Directory.CreateDirectory(DataDirectory); File.AppendAllText(History, JsonSerializer.Serialize(item) + Environment.NewLine, Encoding.UTF8); }
    public List<NetworkEvent> ReadHistory(int limit)
    {
        if (!File.Exists(History)) return new();
        var result = new List<NetworkEvent>();
        foreach (string line in File.ReadLines(History).Reverse().Take(limit))
        {
            try { var item = JsonSerializer.Deserialize<NetworkEvent>(line, JsonOptions.Options); if (item is not null) result.Add(item); } catch { }
        }
        return result;
    }
    public void ClearHistory() { if (File.Exists(History)) File.Delete(History); }
    public void ReportError(string title, Exception? error)
    {
        Directory.CreateDirectory(DataDirectory);
        File.AppendAllText(Path.Combine(DataDirectory, "startup-error.log"), $"{DateTimeOffset.Now:O} {title}\r\n{error}\r\n\r\n", Encoding.UTF8);
    }
}

internal sealed record AllowedRule(string Name, string Type, string Target);
internal sealed record ServiceInfo(string Name, string DisplayName, uint ProcessId);

internal sealed class ServicePickerForm : Form
{
    private readonly DataGridView grid = new();
    public ServiceInfo? SelectedService { get; private set; }
    public ServicePickerForm(List<ServiceInfo> services)
    {
        Text = "Выберите службу Windows"; Width = 760; Height = 520; StartPosition = FormStartPosition.CenterParent;
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.DataSource = services;
        var ok = new Button { Text = "Разрешить выбранную службу", Dock = DockStyle.Bottom, Height = 42 };
        ok.Click += (_, _) => { SelectedService = grid.CurrentRow?.DataBoundItem as ServiceInfo; if (SelectedService is not null) DialogResult = DialogResult.OK; };
        Controls.Add(grid); Controls.Add(ok);
    }
}

internal sealed record NetworkEvent(DateTime Time, string Result, string Application, string ProcessId, string Direction,
    string Protocol, string Source, string Destination)
{
    public static NetworkEvent FromRecord(EventRecord record)
    {
        var doc = XDocument.Parse(record.ToXml());
        XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
        var values = doc.Descendants(ns + "Data").Where(x => x.Attribute("Name") != null)
            .ToDictionary(x => x.Attribute("Name")!.Value, x => x.Value, StringComparer.OrdinalIgnoreCase);
        string Get(string key) => values.TryGetValue(key, out var value) ? value : "";
        string result = record.Id switch { 5156 => "РАЗРЕШЕНО", 5152 or 5157 => "ЗАБЛОКИРОВАНО", _ => record.Id.ToString() };
        string protocol = Get("Protocol") switch { "6" => "TCP", "17" => "UDP", var p => p };
        return new(record.TimeCreated ?? DateTime.Now, result, Get("Application"), Get("ProcessID"), Get("Direction"), protocol,
            $"{Get("SourceAddress")}:{Get("SourcePort")}", $"{Get("DestAddress")}:{Get("DestPort")}");
    }
}

internal static class JsonOptions
{
    public static readonly JsonSerializerOptions Options = new() { PropertyNameCaseInsensitive = true };
}

# Run from elevated Windows PowerShell. This tool does not require NetGuard.exe to start.
# It imports the saved configuration; it never runs 'netsh advfirewall reset'.
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run Windows PowerShell as administrator, then run this script.'
}
$root = Join-Path $env:ProgramData 'NetGuard'
$backup = Join-Path $root 'firewall-before-netguard.wfw'
if (-not (Test-Path -LiteralPath $backup)) { throw "Backup not found: $backup" }
$hashFile = "$backup.sha256"
if (Test-Path -LiteralPath $hashFile) {
    $expected = (Get-Content -LiteralPath $hashFile -Raw).Trim()
    if ((Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash -ne $expected) { throw 'Backup hash mismatch; nothing changed.' }
}
$mutex = New-Object Threading.Mutex($false, 'Global\NetGuard9.Policy')
$owned = $false
try {
    try { $owned = $mutex.WaitOne(180000) } catch [Threading.AbandonedMutexException] { $owned = $true }
    if (-not $owned) { throw 'Another firewall operation is still running.' }
    & "$env:SystemRoot\System32\netsh.exe" advfirewall import $backup
    if ($LASTEXITCODE -ne 0) { throw "Import failed: $LASTEXITCODE. Backup preserved." }
    $policyFile = Join-Path $root 'policy-v9.json'
    if (Test-Path -LiteralPath $policyFile) {
        $policy = Get-Content -LiteralPath $policyFile -Raw | ConvertFrom-Json
        $policy.Mode = 0; $policy.Changing = $false; $policy.RollbackAt = $null
        $policy.Rules = @($policy.Rules | Where-Object { $null -eq $_.Until })
        $policy | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath "$policyFile.recovery" -Encoding UTF8
        Move-Item -LiteralPath "$policyFile.recovery" -Destination $policyFile -Force
    }
    foreach ($name in @('strict-mode.enabled','transition.pending')) {
        $p = Join-Path $root $name
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p }
    }
    Move-Item -LiteralPath $backup -Destination (Join-Path $root 'last-restored.wfw') -Force
    if (Test-Path -LiteralPath $hashFile) { Remove-Item -LiteralPath $hashFile }
    Write-Host 'Firewall restored successfully. Original Windows rules are active.'
    $audit = Join-Path $root 'audit-before-netguard.csv'
    if (Test-Path -LiteralPath $audit) {
        & "$env:SystemRoot\System32\auditpol.exe" /restore "/file:$audit"
        if ($LASTEXITCODE -ne 0) { Write-Warning 'Audit restore failed. Network restore succeeded; audit backup preserved.' }
    }
} finally { if ($owned) { $mutex.ReleaseMutex() }; $mutex.Dispose() }

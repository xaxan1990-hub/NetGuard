using System.Collections.Concurrent;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Microsoft.Diagnostics.Tracing.Parsers;
using Microsoft.Diagnostics.Tracing.Session;

namespace NetGuard.V2;

internal sealed class HistoryStore : IDisposable
{
    private readonly BlockingCollection<object> queue = new(50000);
    private readonly Task writer;
    public long Dropped;
    public string Error = "";
    public HistoryStore()
    {
        Directory.CreateDirectory(Data.FileOf("history-v9"));
        writer = Task.Run(() =>
        {
            var streams = new Dictionary<string, StreamWriter>();
            try
            {
                while (!queue.IsCompleted)
                {
                    if (!queue.TryTake(out object? item, 1000)) continue;
                    int count = 0;
                    do
                    {
                        try
                        {
                            DateTime time = item is NetEvent e ? e.Time : ((TrafficPoint)item).Time;
                            string kind = item is NetEvent ? "events" : "traffic";
                            string file = Path.Combine(Data.FileOf("history-v9"), $"{kind}-{time:yyyy-MM-dd}.jsonl");
                            if (!streams.TryGetValue(file, out var sink))
                            {
                                if (streams.Count >= 4) { foreach (var s in streams.Values) s.Dispose(); streams.Clear(); }
                                sink = new StreamWriter(new FileStream(file, FileMode.Append, FileAccess.Write, FileShare.ReadWrite), new UTF8Encoding(false));
                                streams[file] = sink;
                            }
                            sink.WriteLine(JsonSerializer.Serialize(item, item.GetType(), Data.Json));
                        }
                        catch (Exception ex) { Error = ex.Message; Interlocked.Increment(ref Dropped); }
                    } while (++count < 256 && queue.TryTake(out item));
                    foreach (var sink in streams.Values) try { sink.Flush(); } catch (Exception ex) { Error = ex.Message; }
                }
            }
            finally { foreach (var sink in streams.Values) try { sink.Dispose(); } catch (Exception ex) { Error = ex.Message; } }
        });
    }
    public void Add(object item)
    {
        try { if (!queue.TryAdd(item)) Interlocked.Increment(ref Dropped); }
        catch (InvalidOperationException) { Interlocked.Increment(ref Dropped); }
    }
    public static IEnumerable<T> Read<T>(string kind, DateTime start, DateTime end)
    {
        string dir = Data.FileOf("history-v9"); if (!Directory.Exists(dir)) yield break;
        foreach (string file in Directory.EnumerateFiles(dir, kind + "-*.jsonl").OrderByDescending(x => x))
        {
            string day = Path.GetFileNameWithoutExtension(file)[(kind.Length + 1)..];
            if (!DateTime.TryParseExact(day, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out var date) || date.Date < start.Date || date.Date > end.Date) continue;
            using var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(stream);
            while (reader.ReadLine() is { } line)
            {
                T? value;
                try { value = JsonSerializer.Deserialize<T>(line, Data.Json); } catch (JsonException) { continue; }
                if (value != null) yield return value;
            }
        }
        // Previous releases stored a single JSONL file; include it without modifying or duplicating it.
        if (kind == "events" && typeof(T) == typeof(NetEvent) && File.Exists(Data.FileOf("history.jsonl")))
        {
            using var stream = new FileStream(Data.FileOf("history.jsonl"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using var reader = new StreamReader(stream);
            while (reader.ReadLine() is { } line)
            {
                var item = ParseLegacy(line);
                if (item != null && item.Time >= start && item.Time < end) yield return (T)(object)item;
            }
        }
    }
    private static NetEvent? ParseLegacy(string line)
    {
        try
        {
            using var doc = JsonDocument.Parse(line); var e = doc.RootElement;
            string Get(string p) => e.TryGetProperty(p, out var v) ? v.ToString() : "";
            string direction = Get("Direction") switch { "%%14592" => "Входящее", "%%14593" => "Исходящее", var v => v };
            int.TryParse(Get("ProcessId"), out int pid);
            return new(DateTime.Parse(Get("Time")), ProcessCatalog.Normalize(Get("Application")), pid,
                Get("Result") == "РАЗРЕШЕНО" ? "Разрешено" : "Заблокировано", direction, Get("Protocol"),
                direction == "Входящее" ? Get("Destination") : Get("Source"), direction == "Входящее" ? Get("Source") : Get("Destination"));
        }
        catch { return null; }
    }
    public void Dispose() { queue.CompleteAdding(); writer.Wait(); queue.Dispose(); }
}

internal sealed record RunningApp(string Path, int Pid, long Started);
internal sealed class ProcessCatalog
{
    private volatile Dictionary<int, RunningApp> snapshot = new();
    public RunningApp[] All => snapshot.Values.ToArray();
    public void Refresh()
    {
        var next = new Dictionary<int, RunningApp>();
        foreach (var p in Process.GetProcesses())
        {
            using (p) try
            {
                string? path = p.MainModule?.FileName;
                if (path != null) next[p.Id] = new(path, p.Id, p.StartTime.ToUniversalTime().Ticks);
            }
            catch { }
        }
        snapshot = next;
    }
    public string At(int pid, DateTime time) => snapshot.TryGetValue(pid, out var p) && p.Started <= time.ToUniversalTime().Ticks ? p.Path : $"Неопознанный процесс (PID {pid})";
    public static string Normalize(string path)
    {
        if (path.StartsWith(@"\device\", StringComparison.OrdinalIgnoreCase))
            foreach (string drive in Environment.GetLogicalDrives())
            {
                var b = new StringBuilder(1024);
                if (QueryDosDevice(drive[..2], b, b.Capacity) == 0) continue;
                string prefix = b.ToString();
                if (path.StartsWith(prefix + "\\", StringComparison.OrdinalIgnoreCase)) return drive[..2] + path[prefix.Length..];
            }
        return path.Length == 0 ? "Неопознанный источник" : path;
    }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern uint QueryDosDevice(string name, StringBuilder target, int capacity);
}

internal sealed class Counter
{
    public long Sent, Received, IntervalSent, IntervalReceived;
    public double Upload, Download;
}
internal sealed class TrafficMonitor : IDisposable
{
    private TraceEventSession? session;
    private readonly ProcessCatalog catalog;
    private readonly HistoryStore history;
    private readonly object gate = new();
    private readonly Dictionary<string, Counter> counters = new(StringComparer.OrdinalIgnoreCase);
    private readonly Stopwatch elapsed = Stopwatch.StartNew();
    public string Status = "Запуск ETW…";
    public TrafficMonitor(ProcessCatalog catalog, HistoryStore history) { this.catalog = catalog; this.history = history; }
    public void Start()
    {
        try
        {
            session = new TraceEventSession("NetGuard9-" + Environment.ProcessId);
            session.EnableKernelProvider(KernelTraceEventParser.Keywords.NetworkTCPIP);
            var k = session.Source.Kernel;
            k.TcpIpSend += d => Count(d.ProcessID, d.TimeStamp, d.size, true);
            k.TcpIpRecv += d => Count(d.ProcessID, d.TimeStamp, d.size, false);
            k.TcpIpSendIPV6 += d => Count(d.ProcessID, d.TimeStamp, d.size, true);
            k.TcpIpRecvIPV6 += d => Count(d.ProcessID, d.TimeStamp, d.size, false);
            k.UdpIpSend += d => Count(d.ProcessID, d.TimeStamp, d.size, true);
            k.UdpIpRecv += d => Count(d.ProcessID, d.TimeStamp, d.size, false);
            k.UdpIpSendIPV6 += d => Count(d.ProcessID, d.TimeStamp, d.size, true);
            k.UdpIpRecvIPV6 += d => Count(d.ProcessID, d.TimeStamp, d.size, false);
            Status = "ETW: TCP/UDP, IPv4/IPv6";
            var current = session;
            Task.Run(() => { try { current.Source.Process(); } catch (Exception ex) { Status = "ETW остановлен: " + ex.Message; Data.Log(Status, ex); } });
        }
        catch (Exception ex) { Status = "Учёт байтов недоступен: " + ex.Message; Data.Log(Status, ex); session?.Dispose(); session = null; }
    }
    private void Count(int pid, DateTime time, int size, bool sent)
    {
        if (size < 0) return;
        string path = catalog.At(pid, time);
        lock (gate)
        {
            if (!counters.TryGetValue(path, out var c)) counters[path] = c = new();
            if (sent) { c.Sent += size; c.IntervalSent += size; } else { c.Received += size; c.IntervalReceived += size; }
        }
    }
    public Dictionary<string, Counter> Sample()
    {
        lock (gate)
        {
            double seconds = Math.Max(0.001, elapsed.Elapsed.TotalSeconds); elapsed.Restart();
            var copy = new Dictionary<string, Counter>(StringComparer.OrdinalIgnoreCase);
            foreach (var (path, c) in counters)
            {
                c.Upload = c.IntervalSent / seconds; c.Download = c.IntervalReceived / seconds;
                if (c.IntervalSent != 0 || c.IntervalReceived != 0) history.Add(new TrafficPoint(DateTime.Now, path, c.IntervalSent, c.IntervalReceived));
                c.IntervalSent = c.IntervalReceived = 0;
                copy[path] = new Counter { Sent = c.Sent, Received = c.Received, Upload = c.Upload, Download = c.Download };
            }
            return copy;
        }
    }
    public long Lost => session?.Source.EventsLost ?? 0;
    public void Dispose() { session?.Dispose(); Sample(); }
}

internal sealed class AuditMonitor : IDisposable
{
    private EventLogWatcher? watcher;
    public string Status = "Запуск аудита…";
    public event Action<NetEvent>? Received;
    public static void RestoreAudit()
    {
        string file = Data.FileOf("audit-before-netguard.csv");
        if (!File.Exists(file)) return;
        try { Commands.Run("auditpol.exe", "/restore", "/file:" + file); File.Move(file, Data.FileOf("last-restored-audit.csv"), true); }
        catch (Exception ex) { Data.Log("Политика аудита не восстановлена; копия сохранена", ex); throw; }
    }
    public void Start()
    {
        try
        {
            if (!File.Exists(Data.FileOf("audit-before-netguard.csv"))) Commands.Run("auditpol.exe", "/backup", "/file:" + Data.FileOf("audit-before-netguard.csv"));
            foreach (string id in new[] { "{0CCE9225-69AE-11D9-BED3-505054503030}", "{0CCE9226-69AE-11D9-BED3-505054503030}" })
                Commands.Run("auditpol.exe", "/set", "/subcategory:" + id, "/success:enable", "/failure:enable");
            watcher = new EventLogWatcher(new EventLogQuery("Security", PathType.LogName, "*[System[(EventID=5152 or EventID=5156 or EventID=5157)]]"));
            watcher.EventRecordWritten += (_, args) =>
            {
                if (args.EventException != null) { Status = "Аудит: " + args.EventException.Message; return; }
                using var r = args.EventRecord; if (r == null) return;
                try
                {
                    XNamespace ns = "http://schemas.microsoft.com/win/2004/08/events/event";
                    var d = XDocument.Parse(r.ToXml()).Descendants(ns + "Data").Where(x => x.Attribute("Name") != null).GroupBy(x => x.Attribute("Name")!.Value).ToDictionary(g => g.Key, g => g.Last().Value, StringComparer.OrdinalIgnoreCase);
                    string Get(string key) => d.GetValueOrDefault(key, "");
                    string pidText = Get("ProcessID");
                    int pid = pidText.StartsWith("0x") ? Convert.ToInt32(pidText[2..], 16) : int.TryParse(pidText, out var n) ? n : 0;
                    string dir = Get("Direction") switch { "%%14592" => "Входящее", "%%14593" => "Исходящее", var v => v };
                    string source = $"[{Get("SourceAddress")}]:{Get("SourcePort")}", dest = $"[{Get("DestAddress")}]:{Get("DestPort")}";
                    Received?.Invoke(new(r.TimeCreated ?? DateTime.Now, ProcessCatalog.Normalize(Get("Application")), pid,
                        r.Id == 5156 ? "Разрешено" : "Заблокировано", dir, Get("Protocol") switch { "6" => "TCP", "17" => "UDP", var v => v },
                        dir == "Входящее" ? dest : source, dir == "Входящее" ? source : dest));
                }
                catch (Exception ex) { Data.Log("Не удалось разобрать сетевое событие", ex); }
            };
            watcher.Enabled = true; Status = "Аудит разрешений и запретов включён";
        }
        catch (Exception ex) { Status = "Аудит недоступен: " + ex.Message; Data.Log(Status, ex); }
    }
    public void Dispose() => watcher?.Dispose();
}

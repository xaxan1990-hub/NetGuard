using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace NetGuard.V2;

internal enum AccessMode { Normal, Whitelist, Ask, Lockdown }
internal sealed record AccessRule(string Target, bool Service, bool Allow);
internal sealed class Policy
{
    public AccessMode Mode { get; set; }
    public List<AccessRule> Rules { get; set; } = new();
    public DateTime? RollbackAt { get; set; }
    public bool Changing { get; set; }
    public bool Quiet { get; set; }
    public bool AutoStart { get; set; }
}
internal sealed record NetEvent(DateTime Time, string App, int Pid, string Decision, string Direction, string Protocol, string Local, string Remote);
internal sealed record TrafficPoint(DateTime Time, string App, long Sent, long Received);
internal sealed record ServiceItem(string Name, string DisplayName, uint ProcessId, string State);

internal static class Data
{
    public static readonly string Root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NetGuard");
    public static string FileOf(string name) => Path.Combine(Root, name);
    public static readonly JsonSerializerOptions Json = new() { PropertyNameCaseInsensitive = true, WriteIndented = false };
    private static readonly object logLock = new();
    public static T Read<T>(string name, T fallback)
    {
        string p = FileOf(name);
        return File.Exists(p) ? JsonSerializer.Deserialize<T>(File.ReadAllText(p), Json) ?? fallback : fallback;
    }
    public static void Write<T>(string name, T value)
    {
        Directory.CreateDirectory(Root);
        string tmp = FileOf(name + "." + Guid.NewGuid().ToString("N") + ".tmp");
        File.WriteAllText(tmp, JsonSerializer.Serialize(value, Json), new UTF8Encoding(false));
        File.Move(tmp, FileOf(name), true);
    }
    public static void Log(string message, Exception? error = null)
    {
        lock (logLock)
        {
            try { Directory.CreateDirectory(Root); File.AppendAllText(FileOf("startup-error.log"), $"{DateTimeOffset.Now:O} [0.9] {message}\r\n{error}\r\n", Encoding.UTF8); }
            catch { /* Logging failure must not reverse an already completed firewall operation. */ }
        }
    }
    public static string Hash(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));
}

internal static class Commands
{
    public static string Quote(string value) => "'" + value.Replace("'", "''") + "'";
    public static string PowerShell(string script) => Run("powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand",
        Convert.ToBase64String(Encoding.Unicode.GetBytes("$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.Encoding]::UTF8; " + script)));
    public static string Run(string file, params string[] args)
    {
        var info = new ProcessStartInfo(file) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        if (file.Equals("powershell.exe", StringComparison.OrdinalIgnoreCase)) info.StandardOutputEncoding = Encoding.UTF8;
        foreach (string a in args) info.ArgumentList.Add(a);
        using var p = Process.Start(info) ?? throw new InvalidOperationException("Не удалось запустить " + file);
        var output = p.StandardOutput.ReadToEndAsync(); var error = p.StandardError.ReadToEndAsync();
        if (!p.WaitForExit(90000)) { p.Kill(true); throw new TimeoutException(file + ": превышено время ожидания. Операция требует проверки."); }
        Task.WaitAll(output, error);
        if (p.ExitCode != 0) throw new InvalidOperationException($"{file}: код {p.ExitCode}\r\n{error.Result}\r\n{output.Result}");
        return output.Result.Trim();
    }
}

internal sealed class Firewall
{
    private const string Group = "NetGuard Managed Rules";
    private const string Backup = "firewall-before-netguard.wfw";
    public static string RuleId(AccessRule r) => "NetGuard9-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes((r.Service ? "service:" : "app:") + r.Target.ToUpperInvariant())))[..24];
    public Policy Get() => Locked(() => Load());
    private Policy Load()
    {
        if (File.Exists(Data.FileOf("policy-v9.json"))) return Data.Read("policy-v9.json", new Policy());
        var p = new Policy { Mode = File.Exists(Data.FileOf("strict-mode.enabled")) ? AccessMode.Whitelist : AccessMode.Normal, Changing = File.Exists(Data.FileOf("transition.pending")) };
        // Preserve existing app/service permissions during an upgrade.
        string json = Commands.PowerShell("ConvertTo-Json -Compress -InputObject @(" + OwnRules + " | Where-Object Action -eq 'Allow' | ForEach-Object { $a=($_|Get-NetFirewallApplicationFilter).Program; $s=($_|Get-NetFirewallServiceFilter).Service; if($s -and $s -ne 'Any'){[pscustomobject]@{Target=$s;Service=$true;Allow=$true}} elseif($a -and $a -ne 'Any'){[pscustomobject]@{Target=$a;Service=$false;Allow=$true}} })");
        if (!string.IsNullOrWhiteSpace(json)) p.Rules = (JsonSerializer.Deserialize<List<AccessRule>>(json, Data.Json) ?? new()).DistinctBy(r => RuleId(r)).ToList();
        Save(p); return p;
    }
    private static string OwnRules => $"Get-NetFirewallRule -PolicyStore PersistentStore | Where-Object Group -eq {Commands.Quote(Group)}";
    private static void Save(Policy p) => Data.Write("policy-v9.json", p);
    public static T Locked<T>(Func<T> work)
    {
        using var mutex = new Mutex(false, @"Global\NetGuard9.Policy");
        bool owned;
        try { owned = mutex.WaitOne(TimeSpan.FromMinutes(3)); } catch (AbandonedMutexException) { owned = true; }
        if (!owned) throw new TimeoutException("Другая операция с правилами ещё выполняется.");
        try { return work(); } finally { mutex.ReleaseMutex(); }
    }
    public void ChangeMode(AccessMode mode, bool rescue) => Locked(() =>
    {
        Policy p = Load();
        if (mode == AccessMode.Normal) { RestoreCore(p); return 0; }
        p.Changing = true; Save(p);
        try
        {
            if (p.Mode == AccessMode.Normal) EnsureBackup();
            VerifyBackup();
            p.Mode = mode;
            Commands.PowerShell("Get-NetFirewallRule -PolicyStore PersistentStore -Enabled True -Action Allow | Disable-NetFirewallRule; Set-NetFirewallProfile -Profile Domain,Private,Public -Enabled True -DefaultInboundAction Block -DefaultOutboundAction Block");
            Apply(p);
            p.Changing = false; p.RollbackAt = rescue ? DateTime.UtcNow.AddSeconds(60) : null; Save(p);
            File.WriteAllText(Data.FileOf("strict-mode.enabled"), "v9");
            Data.Log("Режим применён: " + mode + (rescue ? "; возврат через 60 секунд без подтверждения" : ""));
        }
        catch { try { RestoreCore(p); } catch (Exception ex) { Data.Log("Не удалось выполнить откат", ex); } throw; }
        return 0;
    });
    public void Confirm() => Locked(() => { var p = Load(); p.RollbackAt = null; Save(p); Data.Log("Пользователь подтвердил сохранение режима"); return 0; });
    public void Restore() => Locked(() => { RestoreCore(Load()); return 0; });
    private static void EnsureBackup()
    {
        if (!File.Exists(Data.FileOf(Backup))) Commands.Run("netsh.exe", "advfirewall", "export", Data.FileOf(Backup));
        if (new FileInfo(Data.FileOf(Backup)).Length == 0) throw new IOException("Пустая резервная копия: блокировка отменена.");
        if (!File.Exists(Data.FileOf(Backup + ".sha256"))) File.WriteAllText(Data.FileOf(Backup + ".sha256"), Data.Hash(Data.FileOf(Backup)));
    }
    private static void VerifyBackup()
    {
        if (!File.Exists(Data.FileOf(Backup)) || new FileInfo(Data.FileOf(Backup)).Length == 0) throw new IOException("Нет резервной копии брандмауэра.");
        if (File.Exists(Data.FileOf(Backup + ".sha256")) && File.ReadAllText(Data.FileOf(Backup + ".sha256")) != Data.Hash(Data.FileOf(Backup))) throw new IOException("Контрольная сумма резервной копии не совпадает.");
    }
    private static void RestoreCore(Policy p)
    {
        Data.Log("Начато восстановление брандмауэра");
        if (File.Exists(Data.FileOf(Backup)))
        {
            VerifyBackup(); Commands.Run("netsh.exe", "advfirewall", "import", Data.FileOf(Backup));
        }
        else if (p.Mode != AccessMode.Normal) throw new IOException("Нет копии исходных правил. Автоматический сброс не выполнялся.");
        else Commands.PowerShell(OwnRules + " | Remove-NetFirewallRule");
        p.Mode = AccessMode.Normal; p.Changing = false; p.RollbackAt = null; Save(p);
        File.Delete(Data.FileOf("strict-mode.enabled")); File.Delete(Data.FileOf("transition.pending"));
        // Keep the successful backup for manual recovery; next activation takes a fresh snapshot.
        if (File.Exists(Data.FileOf(Backup))) File.Move(Data.FileOf(Backup), Data.FileOf("last-restored.wfw"), true);
        File.Delete(Data.FileOf(Backup + ".sha256"));
        Data.Log("Брандмауэр восстановлен. Действуют исходные правила Windows");
    }
    private static void Apply(Policy p)
    {
        var script = new StringBuilder(OwnRules + " | Remove-NetFirewallRule; ");
        if (p.Mode == AccessMode.Lockdown)
        {
            foreach (string dir in new[] { "Inbound", "Outbound" }) script.Append($"New-NetFirewallRule -Name 'NetGuard9-All-{dir}' -DisplayName 'NetGuard: block all IP' -Group {Commands.Quote(Group)} -Direction {dir} -Action Block -Profile Any -Protocol Any | Out-Null; ");
        }
        else if (p.Mode != AccessMode.Normal)
        {
            foreach (var r in p.Rules)
                foreach (string dir in new[] { "Inbound", "Outbound" })
                    script.Append($"New-NetFirewallRule -Name '{RuleId(r)}-{dir}' -DisplayName {Commands.Quote("NetGuard: " + r.Target)} -Group {Commands.Quote(Group)} -Direction {dir} -Action {(r.Allow ? "Allow" : "Block")} -{(r.Service ? "Service" : "Program")} {Commands.Quote(r.Target)} -Profile Any -Protocol Any | Out-Null; ");
        }
        Commands.PowerShell(script.ToString());
        if (p.Mode != AccessMode.Normal)
        {
            int expected = p.Mode == AccessMode.Lockdown ? 2 : p.Rules.Count * 2;
            Commands.PowerShell("$profiles=@(Get-NetFirewallProfile -PolicyStore ActiveStore); if(@($profiles | Where-Object { $_.Enabled -ne 'True' -or $_.DefaultOutboundAction -ne 'Block' -or $_.DefaultInboundAction -ne 'Block' }).Count -gt 0){throw 'Active firewall policy differs from requested blocking policy (check organizational policy).'}; " +
                $"$rules=@(Get-NetFirewallRule -PolicyStore ActiveStore | Where-Object {{ $_.Group -eq {Commands.Quote(Group)} -and $_.Enabled -eq 'True' }}); if($rules.Count -ne {expected}){{throw 'Not all NetGuard rules are present in the active policy.'}}");
        }
    }
    public void SetRule(AccessRule rule) => Locked(() =>
    {
        var p = Load(); if (p.Mode == AccessMode.Normal) throw new InvalidOperationException("Сначала включите режим запрета с исключениями или запросами.");
        var old = p.Rules.ToList(); p.Rules.RemoveAll(x => x.Service == rule.Service && x.Target.Equals(rule.Target, StringComparison.OrdinalIgnoreCase)); p.Rules.Add(rule);
        // Persist the decision before applying it; recover an interrupted operation.
        p.Changing = true; Save(p);
        try { Apply(p); p.Changing = false; Save(p); Data.Log($"{(rule.Allow ? "Разрешено" : "Запрещено")}: {rule.Target}; до изменения пользователем"); }
        catch { p.Rules = old; try { Apply(p); p.Changing = false; Save(p); } catch { } throw; }
        return 0;
    });
    public void ForgetRules() => Locked(() => { var p = Load(); p.Rules.Clear(); Apply(p); Save(p); return 0; });
    public void Quiet(bool enabled) => Locked(() => { var p = Load(); p.Quiet = enabled; Save(p); return 0; });
    public void Maintain(bool ownerAlive) => Locked(() =>
    {
        var p = Load();
        if (p.Changing || p.RollbackAt <= DateTime.UtcNow) { RestoreCore(p); return 0; }
        return 0;
    });
    public static List<ServiceItem> Services()
    {
        string json = Commands.PowerShell("ConvertTo-Json -Compress -InputObject @(Get-CimInstance Win32_Service | Select-Object Name,DisplayName,ProcessId,State | Sort-Object DisplayName)");
        return JsonSerializer.Deserialize<List<ServiceItem>>(json, Data.Json) ?? new();
    }
    public void AutoStart(bool enabled)
    {
        string exe = Environment.ProcessPath ?? throw new IOException("Нет пути к программе");
        if (enabled)
            Commands.PowerShell($"$a=New-ScheduledTaskAction -Execute {Commands.Quote(exe)} -Argument '--tray'; $t=New-ScheduledTaskTrigger -AtLogOn -User ([Security.Principal.WindowsIdentity]::GetCurrent().Name); $p=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Highest; Register-ScheduledTask -TaskName 'NetGuard UI' -Action $a -Trigger $t -Principal $p -Force | Out-Null");
        else Commands.PowerShell("Get-ScheduledTask | Where-Object TaskName -eq 'NetGuard UI' | Unregister-ScheduledTask -Confirm:$false");
        Locked(() => { var p = Load(); p.AutoStart = enabled; Save(p); return 0; });
    }
}

internal static class ProcessIdentity
{
    public static bool Alive(int pid, long started)
    {
        try { using var p = Process.GetProcessById(pid); return !p.HasExited && p.StartTime.ToUniversalTime().Ticks == started; } catch { return false; }
    }
}

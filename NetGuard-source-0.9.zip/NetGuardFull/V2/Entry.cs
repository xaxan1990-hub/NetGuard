using System.Diagnostics;

namespace NetGuard.V2;

internal static class Entry
{
    [STAThread]
    public static int Main(string[] args)
    {
        ApplicationConfiguration.Initialize();
        Directory.CreateDirectory(Data.Root);
        try
        {
            if (args.Contains("--self-test")) return SelfTests.Run();
            var firewall = new Firewall();
            if (args.Length == 3 && args[0] == "--guardian")
            {
                int pid = int.Parse(args[1]); long start = long.Parse(args[2]);
                using var ready = new EventWaitHandle(false, EventResetMode.ManualReset, @"Global\NetGuard9.Ready." + pid);
                ready.Set();
                do
                {
                    bool alive = ProcessIdentity.Alive(pid, start);
                    try { firewall.Maintain(alive); } catch (Exception ex) { Data.Log("Ошибка сторожевого процесса", ex); }
                    if (!alive) break;
                    Thread.Sleep(1000);
                } while (true);
                return 0;
            }
            if (args.Contains("--recover")) { firewall.Maintain(false); return 0; }
            if (args.Contains("--restore"))
            {
                firewall.Restore();
                try { AuditMonitor.RestoreAudit(); } catch (Exception ex) { MessageBox.Show("Сеть восстановлена. Ошибка восстановления аудита:\r\n" + ex.Message); }
                MessageBox.Show("Исходные правила брандмауэра восстановлены.", "NetGuard"); return 0;
            }
            using var instance = new Mutex(true, @"Global\NetGuard9.UI", out bool first);
            if (!first) { MessageBox.Show("NetGuard уже работает. Откройте его через значок рядом с часами."); return 0; }
            firewall.Maintain(false);
            InstallRecoveryTask();
            using var me = Process.GetCurrentProcess();
            using var readyEvent = new EventWaitHandle(false, EventResetMode.ManualReset, @"Global\NetGuard9.Ready." + me.Id);
            var info = new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = false, CreateNoWindow = true };
            info.ArgumentList.Add("--guardian"); info.ArgumentList.Add(me.Id.ToString()); info.ArgumentList.Add(me.StartTime.ToUniversalTime().Ticks.ToString());
            using var guardian = Process.Start(info) ?? throw new IOException("Не удалось запустить аварийный процесс.");
            if (!readyEvent.WaitOne(10000)) throw new IOException("Аварийный процесс не подтвердил запуск. Изменения сети не выполнялись.");
            Application.ThreadException += (_, e) => { Data.Log("Ошибка интерфейса", e.Exception); MessageBox.Show(e.Exception.Message, "NetGuard"); };
            Application.Run(new MainWindow(firewall, args.Contains("--activate"), args.Contains("--tray")));
            return 0;
        }
        catch (Exception ex)
        {
            Data.Log("Ошибка запуска", ex);
            if (args.Contains("--self-test") || args.Contains("--recover") || args.Contains("--guardian")) Console.Error.WriteLine(ex);
            else MessageBox.Show(ex.Message + "\r\n\r\nЖурнал: " + Data.FileOf("startup-error.log"), "NetGuard — ошибка");
            return 1;
        }
    }
    private static void InstallRecoveryTask()
    {
        Commands.PowerShell($"$a=New-ScheduledTaskAction -Execute {Commands.Quote(Environment.ProcessPath!)} -Argument '--recover'; $t=New-ScheduledTaskTrigger -AtStartup; $p=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest; Register-ScheduledTask -TaskName 'NetGuard Recovery' -Action $a -Trigger $t -Principal $p -Force | Out-Null");
    }
}

internal static class SelfTests
{
    public static int Run()
    {
        // No firewall/audit/task changes. Called by Windows build before creating the installer.
        void Assert(bool ok, string name) { if (!ok) throw new Exception("TEST FAILED: " + name); }
        Assert(Commands.Quote("a'b") == "'a''b'", "PowerShell literal quoting");
        var a = new AccessRule(@"C:\Apps\Test.exe", false, true);
        Assert(Firewall.RuleId(a) == Firewall.RuleId(a with { Target = @"c:\apps\TEST.exe" }), "case-insensitive rule identity");
        Assert(Firewall.RuleId(a) != Firewall.RuleId(a with { Service = true }), "service identity isolation");
        Assert(!ProcessIdentity.Alive(-1, 0), "dead guardian owner");
        Assert(Details.Csv("=1+1").StartsWith("\"'="), "CSV formula protection");
        Assert(Details.InNetwork("2001:db8::1", "2001:db8::/32"), "IPv6 CIDR");
        Assert(!Details.InNetwork("10.0.0.1", "192.168.0.0/16"), "IPv4 CIDR exclusion");
        using (var window = new MainWindow(new Firewall(), false, false, true))
        {
            window.Show(); Application.DoEvents();
            Assert(window.IsHandleCreated && window.Visible, "main window creation");
            window.Close();
        }
        Data.Log("Self-test: 8 проверок пройдено, включая создание окна без изменения сети"); return 0;
    }
}

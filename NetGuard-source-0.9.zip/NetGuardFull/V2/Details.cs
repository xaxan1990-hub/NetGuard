using System.Diagnostics;
using System.Net;
using System.Text.Json;

namespace NetGuard.V2;

internal static class Details
{
    public static string Csv(string text)
    {
        if (text.Length > 0 && "=+-@\t\r".Contains(text[0])) text = "'" + text;
        return "\"" + text.Replace("\"", "\"\"") + "\"";
    }
    public static string Ip(string endpoint)
    {
        if (endpoint.StartsWith("[") && endpoint.Contains(']')) return endpoint[1..endpoint.IndexOf(']')];
        return endpoint;
    }
    public static bool InNetwork(string address, string cidr)
    {
        string[] parts = cidr.Split('/');
        if (parts.Length != 2 || !IPAddress.TryParse(address, out var ip) || !IPAddress.TryParse(parts[0], out var subnet) || !int.TryParse(parts[1], out int bits)) return false;
        var a = ip.GetAddressBytes(); var b = subnet.GetAddressBytes();
        if (a.Length != b.Length || bits < 0 || bits > a.Length * 8) return false;
        for (int i = 0; i < a.Length && bits > 0; i++, bits -= 8)
        { int mask = 255 << (8 - Math.Min(8, bits)); if ((a[i] & mask) != (b[i] & mask)) return false; }
        return true;
    }
    public static string Country(string endpoint)
    {
        string file = Data.FileOf("countries.csv");
        if (!File.Exists(file)) return "Нет локальной базы (импорт в настройках)";
        string ip = Ip(endpoint);
        foreach (string line in File.ReadLines(file))
        { string[] p = line.Split(',', 2); if (p.Length == 2 && InNetwork(ip, p[0].Trim())) return p[1].Trim(); }
        return "Не определена";
    }
    public static async Task<string> Signature(string path)
    {
        if (!File.Exists(path)) return "Файл недоступен";
        return await Task.Run(() =>
        {
            string raw = Commands.PowerShell($"$s=Get-AuthenticodeSignature -LiteralPath {Commands.Quote(path)}; [pscustomobject]@{{Status=[string]$s.Status;Signer=[string]$s.SignerCertificate.Subject}} | ConvertTo-Json -Compress");
            using var d = JsonDocument.Parse(raw);
            return d.RootElement.GetProperty("Status").GetString() + " — " + d.RootElement.GetProperty("Signer").GetString();
        });
    }
    public static string Publisher(string path)
    { try { return FileVersionInfo.GetVersionInfo(path).CompanyName ?? "Не указан"; } catch { return "Не определён"; } }
}

internal sealed class RequestDialog : Form
{
    public int Choice { get; private set; }
    public RequestDialog(NetEvent item, bool canTemporary)
    {
        Text = "NetGuard — запрос доступа"; Width = 740; Height = 490; MinimumSize = new Size(600, 430); StartPosition = FormStartPosition.CenterParent;
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, Padding = new Padding(18) };
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 65));
        var description = new TextBox { Dock = DockStyle.Fill, ReadOnly = true, Multiline = true, ScrollBars = ScrollBars.Vertical, BorderStyle = BorderStyle.None, BackColor = SystemColors.Control, Font = new Font("Segoe UI", 11) };
        description.Text = $"{Path.GetFileName(item.App)}\r\n{item.App}\r\n\r\nИздатель (данные файла): {Details.Publisher(item.App)}\r\nПодпись: проверяется…\r\n\r\n{item.Direction}, {item.Protocol}\r\nУдалённый адрес: {item.Remote}\r\nСтрана: {Details.Country(item.Remote)}\r\nДомен: не запрашивался\r\n\r\nДо решения действует текущий запрет. Временно — для этого EXE до закрытия процесса, максимум 10 минут. Запрос не удерживает пакет; приложению потребуется повторная попытка.";
        Shown += async (_, _) => { try { string s = await Details.Signature(item.App); if (!IsDisposed) description.Text = description.Text.Replace("проверяется…", s); } catch (Exception ex) { if (!IsDisposed) description.Text = description.Text.Replace("проверяется…", "недоступна: " + ex.Message); } };
        var dns = new Button { Text = "Запросить обратное DNS-имя", AutoSize = true };
        dns.Click += async (_, _) => { dns.Enabled = false; try { var entry = await Dns.GetHostEntryAsync(Details.Ip(item.Remote)).WaitAsync(TimeSpan.FromSeconds(5)); if (!IsDisposed) description.AppendText("\r\nОбратное DNS-имя (не обязательно домен приложения): " + entry.HostName); } catch { if (!IsDisposed) description.AppendText("\r\nDNS-имя недоступно"); } };
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill };
        foreach (var (label, choice) in new[] { ("Разрешить временно", 1), ("Разрешить всегда", 2), ("Запретить всегда", 3) })
        {
            var b = new Button { Text = label, AutoSize = true, Height = 42, Enabled = choice != 1 || canTemporary };
            b.Click += (_, _) => { Choice = choice; DialogResult = DialogResult.OK; }; buttons.Controls.Add(b);
        }
        root.Controls.Add(description, 0, 0); root.Controls.Add(dns, 0, 1); root.Controls.Add(buttons, 0, 2); Controls.Add(root);
        try { using var icon = System.Drawing.Icon.ExtractAssociatedIcon(item.App); if (icon != null) Icon = (Icon)icon.Clone(); } catch { }
    }
}

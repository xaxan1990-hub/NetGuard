using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace NetGuard.V2;

internal sealed record AppRow(Image? Icon, string Name, string Path, string Running, string Permission, string Services, string Sent, string Received, string Upload, string Download);
internal sealed record RuleRow(string Target, string Type, string Permission, string Until);
internal sealed record Query(DateTime From, DateTime To, string Decision, string Direction, string Protocol, string Search);
internal sealed class MainWindow : Form
{
    private readonly Firewall firewall;
    private Policy policy = new();
    private readonly HistoryStore store = new();
    private readonly ProcessCatalog catalog = new();
    private readonly AuditMonitor audit = new();
    private readonly TrafficMonitor traffic;
    private readonly ConcurrentQueue<NetEvent> incoming = new();
    private readonly List<NetEvent> recent = new();
    private readonly Dictionary<string, NetEvent> pending = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, DateTime> postponed = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, Image?> icons = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<(DateTime Time, string App)> blocked = new();
    private List<ServiceItem> services = new();
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 1000 };
    private readonly NotifyIcon tray;
    private readonly Label status = new() { Dock = DockStyle.Fill, Font = new Font("Segoe UI Semibold", 16), AutoSize = true };
    private readonly Label diagnostics = new() { Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(10), AutoEllipsis = true };
    private readonly ComboBox mode = Select(new[] { "Обычный доступ Windows", "Запретить, кроме разрешённых", "Спрашивать о новых приложениях", "Заблокировать всё (без исключений)" }, 310);
    private readonly CheckBox rescue = new() { Text = "Откат через 60 с без подтверждения", Checked = true, AutoSize = true };
    private readonly Button confirm = new() { Text = "Подтвердить режим", AutoSize = true };
    private readonly DataGridView apps = Grid(), events = Grid(), history = Grid(), rules = Grid(), serviceGrid = Grid();
    private readonly TextBox appSearch = new() { Width = 230, PlaceholderText = "Поиск программы" };
    private readonly DateTimePicker from = new() { Value = DateTime.Today, Width = 130 }, to = new() { Value = DateTime.Today.AddDays(1), Width = 130 };
    private readonly ComboBox decision = Select(new[] { "Все решения", "Разрешено", "Заблокировано" }, 150);
    private readonly ComboBox direction = Select(new[] { "Все направления", "Входящее", "Исходящее" }, 145);
    private readonly ComboBox protocol = Select(new[] { "Все протоколы", "TCP", "UDP" }, 120);
    private readonly TextBox historySearch = new() { Width = 250, PlaceholderText = "Программа, IP или порт" };
    private readonly Label pageLabel = new() { AutoSize = true };
    private readonly Label totals = new() { AutoSize = true, MaximumSize = new Size(1100, 0) };
    private readonly RateChart chart = new() { Dock = DockStyle.Fill };
    private bool busy, ticking, closing, promptVisible, initialized, disposed;
    private int page, ticks;
    private long uiDropped;
    private Query? currentQuery;
    private string selectedTrafficApp = "";
    private DateTime lastNotice = DateTime.UtcNow;

    public MainWindow(Firewall firewall, bool activate, bool startHidden, bool testMode = false)
    {
        this.firewall = firewall; traffic = new(catalog, store);
        Text = "NetGuard 0.9.1 — контроль сети"; Width = 1420; Height = 860; MinimumSize = new Size(1000, 650);
        StartPosition = FormStartPosition.CenterScreen; Font = new Font("Segoe UI", 10); BackColor = Color.FromArgb(242, 245, 249);
        Build();
        var menu = new ContextMenuStrip();
        menu.Items.Add("Открыть", null, (_, _) => OpenWindow());
        menu.Items.Add("Заблокировать всё", null, async (_, _) => await Change(AccessMode.Lockdown));
        menu.Items.Add("Вернуть обычный доступ", null, async (_, _) => await Change(AccessMode.Normal));
        menu.Items.Add("Выход (правила сохраняются)", null, (_, _) => { closing = true; Close(); });
        tray = new NotifyIcon { Visible = true, Icon = SystemIcons.Shield, Text = "NetGuard: запуск", ContextMenuStrip = menu };
        tray.DoubleClick += (_, _) => OpenWindow();
        audit.Received += e => { store.Add(e); if (incoming.Count < 20000) incoming.Enqueue(e); else Interlocked.Increment(ref uiDropped); };
        Shown += async (_, _) =>
        {
            if (testMode) return;
            await Work(async () =>
            {
                policy = await Task.Run(firewall.Get);
                await Task.Run(catalog.Refresh);
                await Task.Run(() => { audit.Start(); traffic.Start(); });
                services = await Task.Run(Firewall.Services); serviceGrid.DataSource = services;
                initialized = true; mode.SelectedIndex = (int)policy.Mode; RenderPolicy();
            });
            timer.Start();
            if (activate && initialized) await Change(AccessMode.Whitelist);
            if (startHidden) Hide();
        };
        timer.Tick += async (_, _) => await Tick();
        FormClosing += (_, e) =>
        {
            if (!testMode && !closing && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Hide(); }
            else if (busy || ticking || promptVisible) { e.Cancel = true; closing = false; MessageBox.Show("Дождитесь завершения текущей операции."); }
        };
    }
    private void OpenWindow() { Show(); WindowState = FormWindowState.Normal; Activate(); }
    private static ComboBox Select(string[] entries, int width)
    { var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = width }; c.Items.AddRange(entries); c.SelectedIndex = 0; return c; }
    private static DataGridView Grid() => new SmoothGrid
    {
        Dock = DockStyle.Fill, ReadOnly = true, AutoGenerateColumns = false, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
        AllowUserToOrderColumns = true, AllowUserToResizeColumns = true, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
        BackgroundColor = Color.White, RowHeadersVisible = false, BorderStyle = BorderStyle.None, MultiSelect = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect, RowTemplate = { Height = 34 }, ColumnHeadersHeight = 38
    };
    private static void Columns(DataGridView grid, params (string Property, string Title, int Width)[] columns)
    {
        foreach (var (p, t, w) in columns) grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = p, Name = p, HeaderText = t, Width = w, MinimumWidth = 55, SortMode = DataGridViewColumnSortMode.NotSortable });
        grid.EnableHeadersVisualStyles = false; grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(227, 234, 244);
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(246, 249, 253);
    }
    private static Button Button(string text, Func<Task> action, Color? color = null)
    {
        var b = new Button { Text = text, AutoSize = true, Height = 37, FlatStyle = FlatStyle.Flat, Padding = new Padding(8, 3, 8, 3), BackColor = color ?? Color.SteelBlue, ForeColor = Color.White };
        b.Click += async (_, _) => await action(); return b;
    }
    private TabPage Page(TabControl tabs, string title, Control body, Control tools)
    { var p = new TabPage(title) { Padding = new Padding(8) }; tools.Dock = DockStyle.Top; p.Controls.Add(body); p.Controls.Add(tools); tabs.TabPages.Add(p); return p; }
    private static FlowLayoutPanel Bar(int height = 52) => new() { Height = height, Dock = DockStyle.Top, AutoScroll = true, Padding = new Padding(3) };
    private void Build()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3, ColumnCount = 1, Padding = new Padding(14) };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 55)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 96)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(status, 0, 0);
        var bar = Bar(90); bar.Controls.Add(mode); bar.Controls.Add(Button("Применить режим", () => Change((AccessMode)mode.SelectedIndex)));
        bar.Controls.Add(Button("Восстановить сеть", () => Change(AccessMode.Normal), Color.SeaGreen));
        bar.Controls.Add(rescue); confirm.Click += async (_, _) => await Work(() => Task.Run(firewall.Confirm)); bar.Controls.Add(confirm);
        root.Controls.Add(bar, 0, 1);
        var tabs = new TabControl { Dock = DockStyle.Fill };
        apps.Columns.Add(new DataGridViewImageColumn { DataPropertyName = "Icon", HeaderText = "", Width = 40, ImageLayout = DataGridViewImageCellLayout.Zoom });
        Columns(apps, ("Name", "Программа", 180), ("Running", "Состояние процесса", 155), ("Permission", "Правило NetGuard", 250),
            ("Sent", "Отправлено за сеанс", 140), ("Received", "Получено за сеанс", 140), ("Upload", "Отправка / с", 120), ("Download", "Получение / с", 120),
            ("Services", "Службы процесса", 280), ("Path", "Полный путь", 420));
        var ab = Bar(); ab.Controls.Add(appSearch);
        ab.Controls.Add(Button("Разрешить", () => AppRule(true))); ab.Controls.Add(Button("Запретить", () => AppRule(false), Color.Firebrick));
        ab.Controls.Add(Button("Статистика приложения", async () => { selectedTrafficApp = (apps.CurrentRow?.DataBoundItem as AppRow)?.Path ?? ""; await Statistics(1); }));
        Page(tabs, "Программы", apps, ab);
        foreach (var g in new[] { events, history })
        {
            Columns(g, ("Time", "Время", 165), ("App", "Программа", 350), ("Pid", "PID", 75), ("Decision", "Решение Windows", 160), ("Direction", "Направление", 140), ("Protocol", "Протокол", 90), ("Local", "Локальный адрес", 200), ("Remote", "Удалённый адрес", 200));
            g.CellFormatting += (_, e) => { if (e.RowIndex >= 0 && g.Rows[e.RowIndex].DataBoundItem is NetEvent item) g.Rows[e.RowIndex].DefaultCellStyle.BackColor = item.Decision == "Разрешено" ? Color.FromArgb(233, 248, 239) : Color.FromArgb(255, 235, 234); };
        }
        var eb = Bar(); eb.Controls.Add(new Label { AutoSize = true, Text = "Последние 2000 событий. Зелёный — разрешено Windows; красный — заблокировано. Это события, не пакеты.", Padding = new Padding(8) });
        Page(tabs, "Сейчас", events, eb);
        var hb = Bar(120);
        hb.Controls.AddRange(new Control[] { new Label { Text = "С", AutoSize = true }, from, new Label { Text = "До (не включая)", AutoSize = true }, to, decision, direction, protocol, historySearch });
        hb.Controls.Add(Button("Найти", async () => { page = 0; currentQuery = CaptureQuery(); await LoadHistory(); }));
        hb.Controls.Add(Button("Назад", async () => { if (page > 0) page--; await LoadHistory(); }));
        hb.Controls.Add(Button("Далее", async () => { page++; await LoadHistory(); }));
        hb.Controls.Add(Button("Экспорт CSV", () => Export(false))); hb.Controls.Add(Button("Экспорт JSON", () => Export(true))); hb.Controls.Add(pageLabel);
        Page(tabs, "История", history, hb);
        Columns(rules, ("Target", "Источник", 530), ("Type", "Тип", 110), ("Permission", "Решение", 180), ("Until", "Срок", 250));
        var rb = Bar(); rb.Controls.Add(Button("Разрешить EXE…", AddExe));
        rb.Controls.Add(Button("Запретить выбранное", async () =>
        {
            if (rules.CurrentRow?.DataBoundItem is RuleRow r) await Work(() => Task.Run(() => firewall.SetRule(new(r.Target, r.Type == "Служба", false))));
        }, Color.Firebrick));
        rb.Controls.Add(Button("Сбросить решения", async () =>
        { if (MessageBox.Show("Удалить все решения NetGuard? В строгом режиме источники останутся запрещены по умолчанию.", "NetGuard", MessageBoxButtons.YesNo) == DialogResult.Yes) await Work(() => Task.Run(firewall.ForgetRules)); }));
        Page(tabs, "Решения", rules, rb);
        Columns(serviceGrid, ("DisplayName", "Служба", 350), ("Name", "Системное имя", 250), ("State", "Состояние", 130), ("ProcessId", "PID", 85));
        var sb = Bar(90); sb.Controls.Add(Button("Обновить", async () => await Work(async () => { services = await Task.Run(Firewall.Services); serviceGrid.DataSource = services; })));
        sb.Controls.Add(Button("Разрешить службу", () => ServiceRule(true))); sb.Controls.Add(Button("Запретить службу", () => ServiceRule(false), Color.Firebrick));
        sb.Controls.Add(new Label { AutoSize = true, Text = "Несколько служб в одном PID — список возможных владельцев, а не доказательство источника конкретного пакета." });
        Page(tabs, "Службы Windows", serviceGrid, sb);
        var tb = Bar(120); tb.Controls.Add(Button("День", () => Statistics(1))); tb.Controls.Add(Button("7 дней", () => Statistics(7))); tb.Controls.Add(Button("30 дней", () => Statistics(30)));
        tb.Controls.Add(Button("Все приложения", async () => { selectedTrafficApp = ""; await Statistics(1); })); tb.Controls.Add(totals);
        Page(tabs, "Трафик", chart, tb);
        BuildSettings(tabs);
        root.Controls.Add(tabs, 0, 2); Controls.Add(root); Controls.Add(diagnostics);
    }
    private void BuildSettings(TabControl tabs)
    {
        var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, AutoScroll = true, Padding = new Padding(20), WrapContents = false };
        panel.Controls.Add(Button("Включить / выключить автозапуск", async () => await Work(() => Task.Run(() => firewall.AutoStart(!policy.AutoStart)))));
        panel.Controls.Add(Button("Включить / выключить «Не беспокоить»", async () => await Work(() => Task.Run(() => firewall.Quiet(!policy.Quiet)))));
        panel.Controls.Add(Button("Открыть папку журналов и резервных копий", () => { Process.Start(new ProcessStartInfo("explorer.exe", Data.Root) { UseShellExecute = true }); return Task.CompletedTask; }));
        panel.Controls.Add(Button("Импортировать локальную базу стран (CIDR,страна)", async () => await Work(() =>
        {
            using var dlg = new OpenFileDialog { Filter = "CSV|*.csv" };
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                if (new FileInfo(dlg.FileName).Length > 32 * 1024 * 1024) throw new IOException("Максимальный размер базы — 32 МБ.");
                File.Copy(dlg.FileName, Data.FileOf("countries.csv"), true);
            }
            return Task.CompletedTask;
        })));
        panel.Controls.Add(new Label { AutoSize = true, MaximumSize = new Size(1000, 0), Text =
            "Учёт TCP/UDP работает, пока запущен NetGuard. История сохраняется локально по дням; закрытие окна сворачивает программу в трей. Выход — через меню значка.\r\n\r\nETW измеряет байты событий сетевого стека; VPN, прокси и пересылка могут менять видимого владельца или давать повторный учёт. Потери событий отображаются внизу окна.\r\n\r\nРазрешение и запрет сохраняются для EXE (всех его экземпляров) до вашего изменения. Закрытие приложения, выход из NetGuard и перезагрузка не отменяют решение. Изменить доступ можно во вкладке «Программы» или «Решения».\r\n\r\n«Заблокировать всё» — правила Windows Firewall для IP-трафика. Это не физическое отключение интерфейса и не обещание блокировки ARP, трафика стороннего драйвера или каждого пакета до загрузки Windows.\r\n\r\nДля ручного восстановления в папке установки находится Restore-Network.ps1. Пункт 10 (дополнительная защита правил) не реализован." });
        Page(tabs, "Настройки и помощь", panel, new Panel { Height = 1 });
    }
    private async Task Work(Func<Task> action)
    {
        if (busy) return; busy = true; UseWaitCursor = true;
        try { await action(); if (initialized) { policy = await Task.Run(firewall.Get); RenderPolicy(); } }
        catch (Exception ex) { Data.Log("Ошибка операции", ex); MessageBox.Show(this, ex.Message + "\r\nЖурнал: " + Data.FileOf("startup-error.log"), "NetGuard", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { busy = false; UseWaitCursor = false; }
    }
    private async Task Change(AccessMode target) => await Work(async () =>
    {
        if (!initialized) return;
        bool rollback = rescue.Checked;
        await Task.Run(() => firewall.ChangeMode(target, rollback));
        mode.SelectedIndex = (int)target;
    });
    private void RenderPolicy()
    {
        string text = policy.Mode switch { AccessMode.Normal => "Действуют исходные правила Windows", AccessMode.Whitelist => "Запрещено по умолчанию • работают исключения", AccessMode.Ask => "Запрещено по умолчанию • включены запросы", _ => "Блокирующие IP-правила • без исключений" };
        status.Text = text; status.ForeColor = policy.Mode == AccessMode.Normal ? Color.SeaGreen : Color.Firebrick;
        tray.Icon = policy.Mode == AccessMode.Normal ? SystemIcons.Information : SystemIcons.Error; tray.Text = "NetGuard: " + policy.Mode;
        confirm.Enabled = policy.RollbackAt != null;
        rules.DataSource = policy.Rules.Select(r => new RuleRow(r.Target, r.Service ? "Служба" : "Программа", r.Allow ? "Разрешено NetGuard" : "Запрещено NetGuard", "До вашего изменения")).ToList();
    }
    private async Task AppRule(bool allow)
    {
        if (apps.CurrentRow?.DataBoundItem is not AppRow row) return;
        if (!File.Exists(row.Path)) { MessageBox.Show("Нет доступного пути к EXE. Выберите файл вручную."); return; }
        if (Path.GetFileName(row.Path).Equals("svchost.exe", StringComparison.OrdinalIgnoreCase)) { MessageBox.Show("Выберите конкретную службу во вкладке «Службы Windows»."); return; }
        await Work(() => Task.Run(() => firewall.SetRule(new(row.Path, false, allow))));
    }
    private async Task AddExe()
    {
        using var dlg = new OpenFileDialog { Filter = "Программы|*.exe" };
        if (dlg.ShowDialog(this) == DialogResult.OK) await Work(() => Task.Run(() => firewall.SetRule(new(dlg.FileName, false, true))));
    }
    private async Task ServiceRule(bool allow)
    {
        if (serviceGrid.CurrentRow?.DataBoundItem is ServiceItem s) await Work(() => Task.Run(() => firewall.SetRule(new(s.Name, true, allow))));
    }
    private async Task Tick()
    {
        if (ticking || busy || closing || !initialized) return; ticking = true;
        try
        {
            ticks++;
            if (ticks % 3 == 0) { await Task.Run(() => firewall.Maintain(true)); await Task.Run(catalog.Refresh); policy = await Task.Run(firewall.Get); RenderPolicy(); }
            if (ticks % 30 == 0) { services = await Task.Run(Firewall.Services); serviceGrid.DataSource = services; }
            int drained = 0;
            while (drained++ < 2000 && incoming.TryDequeue(out var e))
            {
                recent.Add(e);
                if (e.Decision == "Заблокировано")
                {
                    blocked.Add((DateTime.UtcNow, e.App));
                    if (pending.Count < 2000 || pending.ContainsKey(e.App)) pending[e.App] = e;
                }
            }
            if (recent.Count > 2000) recent.RemoveRange(0, recent.Count - 2000);
            if (drained > 1) events.DataSource = recent.AsEnumerable().Reverse().ToList();
            var counters = traffic.Sample();
            RenderApps(counters); chart.Add(counters.Values.Sum(c => c.Upload), counters.Values.Sum(c => c.Download));
            blocked.RemoveAll(x => x.Time < DateTime.UtcNow.AddMinutes(-1));
            if (!policy.Quiet && DateTime.UtcNow - lastNotice > TimeSpan.FromMinutes(1) && blocked.Count > 0)
            {
                var top = blocked.GroupBy(x => x.App).OrderByDescending(g => g.Count()).First();
                tray.ShowBalloonTip(4000, "Сетевая активность", $"{Path.GetFileName(top.Key)}: заблокировано событий за минуту — {top.Count()}", ToolTipIcon.Info); lastNotice = DateTime.UtcNow;
            }
            int countdown = policy.RollbackAt is { } at ? Math.Max(0, (int)(at - DateTime.UtcNow).TotalSeconds) : 0;
            diagnostics.Text = $"{audit.Status} | {traffic.Status}\r\nПотери: ETW {traffic.Lost}, запись {store.Dropped}, экран {uiDropped}. Очередь вопросов: {pending.Count}. Автозапуск: {policy.AutoStart}. Не беспокоить: {policy.Quiet}. " + (policy.RollbackAt != null ? $"ОТКАТ ЧЕРЕЗ {countdown} с" : "") + (store.Error.Length > 0 ? " Ошибка записи: " + store.Error : "");
            if (!promptVisible && policy.Mode == AccessMode.Ask && !policy.Quiet) await NextPrompt();
        }
        catch (Exception ex) { Data.Log("Ошибка обновления", ex); diagnostics.Text = "Ошибка обновления: " + ex.Message; }
        finally { ticking = false; }
    }
    private void RenderApps(Dictionary<string, Counter> counters)
    {
        string? selected = (apps.CurrentRow?.DataBoundItem as AppRow)?.Path;
        var running = catalog.All;
        var paths = running.Select(x => x.Path).Concat(counters.Keys).Concat(recent.Select(x => x.App)).Concat(policy.Rules.Where(x => !x.Service).Select(x => x.Target)).Distinct(StringComparer.OrdinalIgnoreCase);
        var rows = new List<AppRow>();
        foreach (string path in paths.Where(p => p.Contains(appSearch.Text.Trim(), StringComparison.OrdinalIgnoreCase)))
        {
            var instances = running.Where(x => x.Path.Equals(path, StringComparison.OrdinalIgnoreCase)).ToArray();
            var rule = policy.Rules.LastOrDefault(r => !r.Service && r.Target.Equals(path, StringComparison.OrdinalIgnoreCase));
            string access = policy.Mode == AccessMode.Normal ? "Правила Windows" : policy.Mode == AccessMode.Lockdown ? "Общий запрет" : rule == null ? "Запрет по умолчанию" : rule.Allow ? "Разрешение NetGuard" : "Запрет NetGuard";
            counters.TryGetValue(path, out var c);
            if (!icons.ContainsKey(path)) { try { using var i = System.Drawing.Icon.ExtractAssociatedIcon(path); icons[path] = i?.ToBitmap(); } catch { icons[path] = null; } }
            rows.Add(new(icons[path], Path.GetFileName(path), path, instances.Length == 0 ? "Не обнаружен" : "Работает (" + string.Join(",", instances.Select(x => x.Pid)) + ")", access,
                string.Join(", ", services.Where(s => instances.Any(x => x.Pid == s.ProcessId)).Select(s => s.DisplayName)), Bytes(c?.Sent ?? 0), Bytes(c?.Received ?? 0), Bytes(c?.Upload ?? 0), Bytes(c?.Download ?? 0)));
        }
        apps.DataSource = rows.OrderBy(x => x.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
        if (selected != null) foreach (DataGridViewRow row in apps.Rows) if ((row.DataBoundItem as AppRow)?.Path == selected) { apps.CurrentCell = row.Cells[1]; break; }
    }
    private async Task NextPrompt()
    {
        foreach (var pair in pending.ToArray())
        {
            var e = pair.Value;
            if (policy.Rules.Any(r => !r.Service && r.Target.Equals(e.App, StringComparison.OrdinalIgnoreCase))) { pending.Remove(pair.Key); continue; }
            if (!File.Exists(e.App) || !e.App.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || Path.GetFileName(e.App).Equals("svchost.exe", StringComparison.OrdinalIgnoreCase)) { pending.Remove(pair.Key); continue; }
            if (postponed.TryGetValue(e.App, out var untilTime) && untilTime > DateTime.UtcNow) continue;
            promptVisible = true;
            try
            {
                using var dialog = new RequestDialog(e);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    var rule = new AccessRule(e.App, false, dialog.Choice == 2);
                    await Task.Run(() => firewall.SetRule(rule)); policy = await Task.Run(firewall.Get); RenderPolicy(); pending.Remove(pair.Key);
                }
                else postponed[e.App] = DateTime.UtcNow.AddMinutes(5);
            }
            finally { promptVisible = false; }
            break;
        }
    }
    private Query CaptureQuery() => new(from.Value.Date, to.Value.Date, decision.SelectedIndex == 0 ? "" : decision.Text,
        direction.SelectedIndex == 0 ? "" : direction.Text, protocol.SelectedIndex == 0 ? "" : protocol.Text, historySearch.Text.Trim());
    private static IEnumerable<NetEvent> Matching(Query q) => HistoryStore.Read<NetEvent>("events", q.From, q.To).Where(e => e.Time >= q.From && e.Time < q.To && (q.Decision == "" || q.Decision == e.Decision) && (q.Direction == "" || q.Direction == e.Direction) && (q.Protocol == "" || q.Protocol == e.Protocol) && (q.Search == "" || $"{e.App} {e.Local} {e.Remote}".Contains(q.Search, StringComparison.OrdinalIgnoreCase)));
    private async Task LoadHistory() => await Work(async () =>
    {
        currentQuery ??= CaptureQuery(); if (currentQuery.To <= currentQuery.From) throw new InvalidOperationException("Конец периода должен быть позже начала.");
        var q = currentQuery; int skip = page * 500;
        var result = await Task.Run(() => Matching(q).Skip(skip).Take(500).ToList()); history.DataSource = result;
        pageLabel.Text = $"Страница {page + 1}, строк {result.Count}. Дни: от новых к старым.";
    });
    private async Task Export(bool json) => await Work(async () =>
    {
        Query q = CaptureQuery(); if (q.To <= q.From) throw new InvalidOperationException("Некорректный период.");
        using var dlg = new SaveFileDialog { Filter = json ? "JSON|*.json" : "CSV|*.csv", FileName = json ? "netguard-history.json" : "netguard-history.csv" };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        string filename = dlg.FileName;
        await Task.Run(() =>
        {
            using var writer = new StreamWriter(filename, false, new UTF8Encoding(true));
            writer.WriteLine(json ? "[" : "Time,App,PID,Decision,Direction,Protocol,Local,Remote"); bool first = true;
            foreach (var e in Matching(q))
            {
                if (json) { if (!first) writer.WriteLine(","); writer.Write(JsonSerializer.Serialize(e)); first = false; }
                else writer.WriteLine(string.Join(",", new[] { e.Time.ToString("O"), e.App, e.Pid.ToString(), e.Decision, e.Direction, e.Protocol, e.Local, e.Remote }.Select(Details.Csv)));
            }
            if (json) writer.WriteLine("\n]");
        });
        MessageBox.Show("История за выбранный период экспортирована полностью.");
    });
    private async Task Statistics(int days) => await Work(async () =>
    {
        DateTime start = DateTime.Today.AddDays(1 - days), end = DateTime.Now; string app = selectedTrafficApp;
        var sum = await Task.Run(() =>
        {
            long sent = 0, received = 0;
            foreach (var p in HistoryStore.Read<TrafficPoint>("traffic", start, end).Where(p => p.Time >= start && p.Time <= end && (app == "" || p.App.Equals(app, StringComparison.OrdinalIgnoreCase)))) { sent += p.Sent; received += p.Received; }
            return (sent, received);
        });
        totals.Text = $"{(app == "" ? "Все приложения" : Path.GetFileName(app))}: {days} дн. Отправлено {Bytes(sum.sent)}, получено {Bytes(sum.received)}.\r\nГрафик: общий трафик за последние 120 секунд. Синий — отправка, зелёный — получение.";
    });
    internal static string Bytes(double value)
    { string[] units = { "Б", "КиБ", "МиБ", "ГиБ", "ТиБ" }; int i = 0; while (value >= 1024 && i < units.Length - 1) { value /= 1024; i++; } return $"{value:0.0} {units[i]}"; }
    protected override void Dispose(bool disposing)
    {
        if (disposing && !disposed)
        {
            disposed = true;
            timer.Stop(); timer.Dispose(); tray.Dispose(); audit.Dispose(); traffic.Dispose(); store.Dispose();
            foreach (var i in icons.Values) i?.Dispose();
            if (initialized) try { firewall.Maintain(false); } catch (Exception ex) { Data.Log("Ошибка проверки восстановления при выходе", ex); }
            if (initialized) try { AuditMonitor.RestoreAudit(); } catch (Exception ex) { Data.Log("Ошибка восстановления аудита при выходе", ex); }
        }
        base.Dispose(disposing);
    }
}

internal sealed class SmoothGrid : DataGridView { public SmoothGrid() { DoubleBuffered = true; } }
internal sealed class RateChart : Panel
{
    private readonly List<(double Up, double Down)> points = new();
    public RateChart() { DoubleBuffered = true; BackColor = Color.White; }
    public void Add(double up, double down) { points.Add((up, down)); if (points.Count > 120) points.RemoveAt(0); Invalidate(); }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e); if (Width < 100 || Height < 100) return;
        double max = Math.Max(1, points.Select(p => Math.Max(p.Up, p.Down)).DefaultIfEmpty(1).Max());
        e.Graphics.DrawString("Скорость • верхняя граница " + MainWindow.Bytes(max) + "/с", Font, Brushes.DimGray, 15, 10);
        if (points.Count < 2) return;
        for (int line = 0; line < 2; line++)
        {
            using var pen = new Pen(line == 0 ? Color.SteelBlue : Color.SeaGreen, 2);
            var coords = points.Select((p, i) => new PointF(20 + (Width - 40) * i / 119f, Height - 30 - (float)((line == 0 ? p.Up : p.Down) / max) * (Height - 80))).ToArray();
            e.Graphics.DrawLines(pen, coords);
        }
    }
}

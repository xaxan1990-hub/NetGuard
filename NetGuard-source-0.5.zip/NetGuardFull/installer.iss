#define MyAppName "NetGuard"
#define MyAppVersion "0.5.0"
#define MyAppExeName "NetGuard.exe"

[Setup]
AppId={{9FB6D75F-97D2-4B08-A184-1A6CF2054E50}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\NetGuard
DefaultGroupName=NetGuard
OutputDir=installer-output
OutputBaseFilename=NetGuard-Setup-x64
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autodesktop}\NetGuard"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\NetGuard"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Восстановить сеть"; Filename: "{app}\{#MyAppExeName}"; Parameters: "--restore"

[Run]
Filename: "{app}\{#MyAppExeName}"; Parameters: "--activate"; Description: "Запустить NetGuard и включить строгий режим"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{app}\{#MyAppExeName}"; Parameters: "--restore"; Flags: runhidden waituntilterminated
